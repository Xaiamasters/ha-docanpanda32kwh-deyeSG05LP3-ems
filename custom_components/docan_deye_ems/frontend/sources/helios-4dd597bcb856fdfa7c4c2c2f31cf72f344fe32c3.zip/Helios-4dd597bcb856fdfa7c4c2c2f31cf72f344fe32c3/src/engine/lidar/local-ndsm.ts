//Generic local nDSM GeoTIFF / COG shadow source.
//
//Unlike the country-specific providers, this one is not registered in
//the static LIDAR_SOURCES list. The engine builds it on demand from
//the user's card config (via resolveLidarSource()) when, and only
//when, every `lidar-local-ndsm-*` key in the config validates:
//provider enabled, raster URL present, full EPSG:4326 bbox with
//min < max on both axes and both axes inside legal ranges.
//
//The raster is interpreted as "height above ground in metres" (an
//nDSM = DSM - DTM, prepared offline). A bare-earth DEM/DTM is not
//valid input. Cells whose source value matches the file's
//GDAL_NODATA tag are mapped to NaN so the shared pipeline skips
//them; non-finite source values stay NaN; finite negatives are
//clamped to 0 (valid ground); finite non-negatives pass through
//unchanged.
//
//Decoding goes through fetchFloat32GeoTiffWithNoData(), which is a
//thin extension of the existing fetchFloat32GeoTiff() that also
//returns the parsed GDAL_NODATA sentinel from the GeoTIFF metadata
//(or null when the tag is absent). The original helper is left
//untouched so every existing provider keeps the exact same byte
//path.

import type {
    LidarSource,
    LidarShadowFetchOptions,
    LidarShadowResult
} from '../lidar';
import {
    processHeightRaster,
    emptyResult,
    RASTER_DEFAULTS
} from './pipeline';
import { fetchFloat32GeoTiffWithNoData } from './geotiff';

//Fully-validated local nDSM configuration. Produced by
//validateLocalNdsmConfig() in ../lidar.ts. The factory below
//treats every field as already vetted (URL non-empty, bbox finite
//and ordered, inside EPSG:4326 ranges).
export interface LocalNdsmConfig
{
    url:    string;
    minLat: number;
    maxLat: number;
    minLon: number;
    maxLon: number;
}

//Normalise the resampled nDSM band in place. Exported so the behaviour is verifiable from a unit-level test:
//
//  - source value == nodata sentinel        -> NaN
//  - source value is NaN / +/-Infinity      -> NaN
//  - finite negative                        -> 0 (valid ground)
//  - finite non-negative                    -> unchanged
//
//Run exactly once on the resampled raster before processHeightRaster()
//consumes it; resampling does not happen after normalisation.
export function normaliseLocalNdsmRaster(
    band:   Float32Array,
    noData: number | null
): Float32Array
{
    const hasNoData = noData !== null && Number.isFinite(noData);
    for (let i = 0; i < band.length; i++)
    {
        const v = band[i];
        if (hasNoData && v === noData)            { band[i] = NaN; continue; }
        if (!Number.isFinite(v))                  { band[i] = NaN; continue; }
        if (v < 0)                                { band[i] = 0;   continue; }
        //finite, non-negative: leave untouched.
    }
    return band;
}

//Normalise the optional DTM (terrain) band in place. Same nodata
//handling as the nDSM, BUT no negative-floor: terrain elevation is
//absolute, can legitimately sit below sea level (Death Valley
//-86 m, Dead Sea -430 m) and we need the real value so the ray-
//march's `sampleDtm - panelDtm` slope reads correctly. Non-finite
//cells are still mapped to NaN so the ray-march skips them.
export function normaliseLocalDtmRaster(
    band:   Float32Array,
    noData: number | null
): Float32Array
{
    const hasNoData = noData !== null && Number.isFinite(noData);
    for (let i = 0; i < band.length; i++)
    {
        const v = band[i];
        if (hasNoData && v === noData) { band[i] = NaN; continue; }
        if (!Number.isFinite(v))       { band[i] = NaN; continue; }
        //finite: leave untouched (may be negative for below-sea
        //elevations; that's the real terrain value, not no-data).
    }
    return band;
}

//Build a per-config LidarSource. Each call returns a fresh object so
//multiple configs (today: at most one, but the seam is generic)
//cannot share mutable state.
export function createLocalNdsmSource(cfg: LocalNdsmConfig): LidarSource
{
    const { url, minLat, maxLat, minLon, maxLon } = cfg;

    return {
        id:   'local-ndsm',
        name: 'Local nDSM GeoTIFF',
        //Local rasters have no advertised pitch; default to 1 m which
        //covers the common LiDAR DSM / DTM grids users typically prep
        //offline. The engine still scales rasterSize off this value
        //via the precision knob, so a finer source can be exercised by
        //picking "high" precision in the editor.
        nativeCellPitchMeters: 1.0,

        covers(lat: number, lon: number): boolean
        {
            return lat >= minLat && lat <= maxLat
                && lon >= minLon && lon <= maxLon;
        },

        async fetchShadowRegions(opts: LidarShadowFetchOptions): Promise<LidarShadowResult>
        {
            //Clamp the requested raster size to the same bounds the
            //pipeline uses for every other provider; the configured
            //bbox is the geographic frame at runtime (the GeoTIFF is
            //resampled to rasterSize x rasterSize regardless of its
            //own georeferencing).
            const rasterSize = Math.min(RASTER_DEFAULTS.maxRasterSize,
                Math.max(RASTER_DEFAULTS.minRasterSize, Math.round(opts.rasterSize)));

            let band:    Float32Array | null;
            let terrain: Float32Array | null;
            let noData:  number | null;
            try
            {
                const r = await fetchFloat32GeoTiffWithNoData(url, rasterSize, opts.signal);
                band    = r ? r.data    : null;
                terrain = r ? r.terrain : null;
                noData  = r ? r.noData  : null;
            }
            catch (err)
            {
                console.warn('[HELIOS] local-nDSM fetch threw at', url, err);
                return emptyResult();
            }
            if (!band)
            {
                console.warn('[HELIOS] local-nDSM fetch returned no data for', url, '(check the URL is reachable from the browser and serves a Float32 GeoTIFF / COG).');
                return emptyResult();
            }
            if (band.length < rasterSize * rasterSize)
            {
                console.warn('[HELIOS] local-nDSM raster too small at', url, '(got', band.length, 'cells, expected', rasterSize * rasterSize, '). The GeoTIFF is likely below the minimum resolution for the requested precision.');
                return emptyResult();
            }

            normaliseLocalNdsmRaster(band, noData);
            //Same nodata sentinel for both bands; the single noData
            //value reads from band 1's GDAL_NODATA tag, which the
            //pipeline writes identically on band 2.
            if (terrain && terrain.length >= rasterSize * rasterSize)
            {
                normaliseLocalDtmRaster(terrain, noData);
            }
            else
            {
                terrain = null;
            }

            return processHeightRaster(band, {
                rasterSize,
                minLat,
                maxLat,
                minLon,
                maxLon,
                homeLat:          opts.homeLat,
                homeLon:          opts.homeLon,
                cropRadiusMeters: opts.cropRadiusMeters
            }, {}, terrain ?? undefined);
        }
    };
}
