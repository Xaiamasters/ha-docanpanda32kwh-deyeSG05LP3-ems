//Common interface and registry for country-specific LiDAR providers.
//
//Adding a country = drop a new file under ./lidar/providers/ that
//exports a LidarSource and register it in LIDAR_SOURCES below. No
//engine-side changes needed.
//
//Pipeline overview: when the user has shadows enabled AND a provider
//covers the home, the engine calls fetchShadowRegions() with the home
//position and a radius. The provider fetches a height raster around
//the home, runs a size-capped 8-connected flood fill on the cells
//above the height threshold, and emits one convex-hull Polygon per
//capped clump with `render_height` set to the clump's mean cell
//height. Those polygons feed projectExtrusionShadows() exactly like
//the OpenFreeMap building footprints do when LiDAR is unavailable.
//Capping the
//clump area keeps a dense forest from collapsing into one giant
//blanket shadow while preserving the organic, non-grid-aligned
//shape of a convex hull.

export interface LidarSource
{
    //Stable identifier, lowercased and country-prefixed. Goes into logs.
    id:    string;
    //Human-readable label, currently logs-only.
    name:  string;

    //Native cell pitch in metres for the upstream raster as published by the data owner. The engine sizes the requested rasterSize off this value so
    //the fetched grid matches real source samples instead of forcing the server to interpolate up: at "high" precision the engine asks one cell per
    //native sample, "medium" one per 2, "low" one per 4. Lets the LiDAR view + shadows scale with the actual ground truth rather than a fixed pixel
    //count.
    nativeCellPitchMeters: number;

    //Cheap synchronous coverage probe. Implementations should bail
    //fast (a couple of bbox comparisons) so the engine can call this
    //on every home-position change without measurable cost.
    covers(lat: number, lon: number): boolean;

    //Fetch shadow regions around the home as a FeatureCollection of
    //bin polygons with render_height set per bin, together with a
    //small diagnostics bag the engine surfaces through
    //`window.heliosStats()`. Returns an empty collection on network
    //failure, out-of-coverage bbox or empty raster, so the caller
    //can always use the result unconditionally.
    fetchShadowRegions(opts: LidarShadowFetchOptions): Promise<LidarShadowResult>;
}

export interface LidarShadowResult
{
    features:    GeoJSON.FeatureCollection;
    diagnostics:
    {
        //Number of LiDAR cells that passed the height threshold and the circular crop. 0 when the home is outside coverage or the WMS round-trip
        //failed.
        cellsKept:   number;
        //Cells-per-clump cap actually used (derived from the chosen
        //precision). Surfaced so the user can confirm the size cap
        //matches expectations.
        cellsPerClumpCap: number;
        //Min / max kept height in metres. null when no cell passed.
        heightRangeM: [number, number] | null;
    };
    //Raw height raster + geo, forwarded by every provider so the
    //engine can keep it around for the LiDAR View overlay (which
    //projects every cell, threshold-bypassed, to screen).
    //Producers always populate it when the upstream fetch succeeded;
    //consumers that only care about cast shadows can ignore the field.
    raster?:
    {
        heights:    Float32Array;
        //Optional DTM band (ground elevation in the source vertical
        //datum, NaN where no-data). Populated by the local-nDSM
        //provider when it reads a 2-band COG; absent on legacy
        //single-band COGs and on every public
        //provider (their WCS layers only expose the nDSM). The
        //shading ray-march in pv-shading.ts falls back to flat-
        //ground geometry whenever the field is undefined, so the
        //two paths coexist without a flag.
        terrain?:   Float32Array;
        rasterSize: number;
        minLat:     number;
        maxLat:     number;
        minLon:     number;
        maxLon:     number;
    };
}

export interface LidarShadowFetchOptions
{
    homeLat:                  number;
    homeLon:                  number;
    //Radius in metres around the home from which heights are sampled. The provider over-fetches slightly so trees on the edge still cast their shadow
    //inward.
    radiusMeters:             number;
    //Pixel count per side requested from the upstream raster. The engine picks this based on the user's `lidar-precision`.
    rasterSize:               number;
    //Optional circular crop. Cells beyond this distance from the home are dropped so the shadow zones stay inside the visible disc. When unset, the
    //bbox is the only bound.
    cropRadiusMeters?:        number;
    signal?:                  AbortSignal;
}

import { franceLidarHd }              from './lidar/providers/fr';
import { englandLidarComposite }       from './lidar/providers/uk';
import { spainPnoaLidar }              from './lidar/providers/es';
import { netherlandsAhn4 }             from './lidar/providers/nl';
import { norwayKartverketNhm }         from './lidar/providers/no';
import { nrwLidarNdom }                from './lidar/providers/de-nrw';
import { polandGugikNmpt }             from './lidar/providers/pl';
import { canadaHrdem }                 from './lidar/providers/ca';
import { brandenburgBerlinDom }        from './lidar/providers/de-bb-be';
import { vermontVcgiNdsm }             from './lidar/providers/us-vt';
//Baden-Württemberg, Austria Tirol, Austria Steiermark and Belgium Flanders source files (de-bw, at-tirol, at-stmk, be-fl) all
//live under ./lidar/providers/ and remain functional but are NOT currently registered: the DSM-DTM subtraction quality on those
//feeds was judged below the bar set by the existing nDSM providers (per-pixel subtraction amplifies noise on building edges and
//over vegetation, which renders the cast shadows as blobs instead of recognisable footprints). Re-enable by importing +
//appending to LIDAR_SOURCES when a cleaner data path is identified for those regions.
import {
    createLocalNdsmSource,
    type LocalNdsmConfig
} from './lidar/local-ndsm';
import type { HeliosConfig } from '../helios-config';

//Registered providers, ordered by preference. findLidarSource() returns the FIRST provider whose covers() probe accepts the home
//position; there is no fallback chain when the actual fetch turns up no-data, so order is load-bearing whenever two providers'
//bounding boxes overlap. Bbox checks today are non-overlapping (one country / region per provider, plus German Länder keyed by
//state bboxes), single-fetch normalised-raster providers come first (France BIL, NRW nDOM, Poland NMPT, Canada HRDEM DSM,
//Vermont nDSM) because they skip the DSM-DTM subtraction round-trip; DSM-DTM subtraction providers follow.
export const LIDAR_SOURCES: LidarSource[] = [
    franceLidarHd,
    nrwLidarNdom,
    polandGugikNmpt,
    canadaHrdem,
    vermontVcgiNdsm,
    englandLidarComposite,
    spainPnoaLidar,
    netherlandsAhn4,
    norwayKartverketNhm,
    brandenburgBerlinDom
];

export function findLidarSource(lat: number, lon: number): LidarSource | null
{
    for (const src of LIDAR_SOURCES)
    {
        if (src.covers(lat, lon))
        {
            return src;
        }
    }
    return null;
}

//Read the six `lidar-local-ndsm-*` keys off a HeliosConfig and either
//return a fully-typed LocalNdsmConfig (when every required field is
//valid) or null (when the provider is disabled, the URL is missing,
//or any bbox value is missing / non-finite / out of EPSG:4326 range /
//ordered wrong). Never throws; invalid local-provider config never
//invalidates the rest of the card config.
export function validateLocalNdsmConfig(cfg: HeliosConfig | undefined | null): LocalNdsmConfig | null
{
    if (!cfg)
    {
        return null;
    }
    if (cfg['lidar-local-ndsm-enabled'] !== true)
    {
        return null;
    }

    const rawUrl = cfg['lidar-local-ndsm-url'];
    if (typeof rawUrl !== 'string')
    {
        return null;
    }
    const url = rawUrl.trim();
    if (url.length === 0)
    {
        return null;
    }

    const minLat = numFromCfg(cfg['lidar-local-ndsm-min-lat']);
    const maxLat = numFromCfg(cfg['lidar-local-ndsm-max-lat']);
    const minLon = numFromCfg(cfg['lidar-local-ndsm-min-lon']);
    const maxLon = numFromCfg(cfg['lidar-local-ndsm-max-lon']);
    if (minLat === null || maxLat === null || minLon === null || maxLon === null)
    {
        return null;
    }

    if (minLat < -90 || minLat > 90 || maxLat < -90 || maxLat > 90)
    {
        return null;
    }
    if (minLon < -180 || minLon > 180 || maxLon < -180 || maxLon > 180)
    {
        return null;
    }
    if (!(minLat < maxLat))
    {
        return null;
    }
    if (!(minLon < maxLon))
    {
        return null;
    }

    return { url, minLat, maxLat, minLon, maxLon };
}

function numFromCfg(v: unknown): number | null
{
    if (typeof v === 'number' && Number.isFinite(v))
    {
        return v;
    }
    if (typeof v === 'string')
    {
        const s = v.trim();
        if (s.length === 0)
        {
            return null;
        }
        const n = Number(s);
        return Number.isFinite(n) ? n : null;
    }
    return null;
}

//One-shot warning latches. When the user enables the local provider but leaves the config incomplete or invalid, log exactly once per session so the
//silent fall-through is diagnosable without spamming the console on every shadow refresh. Same one-shot pattern for the "bbox valid but does not
//cover the home" case (typical lat / lon swap) and for the silent fall-through onto a public provider.
let _warnedInvalidLocalNdsm = false;
let _warnedBboxDoesNotCoverHome = false;

//Config-aware provider resolver. Behaviour:
//
//  1. When the local-nDSM config validates, construct a per-config
//     LocalNdsmSource and return it if it covers (lat, lon). This
//     takes precedence over any public provider that would otherwise
//     match the same point.
//  2. Otherwise (no local config, or local config does not cover the
//     point) fall back to the existing static LIDAR_SOURCES chain
//     via findLidarSource().
//
//findLidarSource() and the static LIDAR_SOURCES list are unchanged
//and still exported for any caller that does not need config-aware
//resolution.
export function resolveLidarSource(
    lat: number,
    lon: number,
    cfg: HeliosConfig | undefined | null
): LidarSource | null
{
    const localCfg = validateLocalNdsmConfig(cfg);

    if (cfg && cfg['lidar-local-ndsm-enabled'] === true && localCfg === null)
    {
        if (!_warnedInvalidLocalNdsm)
        {
            _warnedInvalidLocalNdsm = true;
            console.warn(
                '[HELIOS] lidar-local-ndsm-enabled is true but the local nDSM '
              + 'config is incomplete or invalid; falling back to public LiDAR '
              + 'providers and the OpenFreeMap building-footprint mask. '
              + 'Required keys: lidar-local-ndsm-url plus the four '
              + 'lidar-local-ndsm-{min,max}-{lat,lon} bbox values in EPSG:4326.'
            );
        }
    }

    if (localCfg)
    {
        const local = createLocalNdsmSource(localCfg);
        if (local.covers(lat, lon))
        {
            return local;
        }
        //Bbox validates but the home is OUTSIDE the rectangle. Most common
        //case is a lat / lon swap in the config (the user pasted longitudes
        //into the *-lat keys and latitudes into the *-lon keys, both pass
        //the bare -90..90 / -180..180 range check). Surface the actual
        //numbers so the user can spot the swap from the console without
        //digging into the source.
        if (!_warnedBboxDoesNotCoverHome)
        {
            _warnedBboxDoesNotCoverHome = true;
            console.warn(
                '[HELIOS] local-nDSM bbox does not cover the home, falling back to public providers.\n'
              + '  home:     lat ' + lat.toFixed(5) + ', lon ' + lon.toFixed(5) + '\n'
              + '  bbox lat: [' + localCfg.minLat + ', ' + localCfg.maxLat + ']\n'
              + '  bbox lon: [' + localCfg.minLon + ', ' + localCfg.maxLon + ']\n'
              + '  If the lat / lon ranges look swapped (latitudes in the lon fields or vice versa), '
              + 'check the four lidar-local-ndsm-{min,max}-{lat,lon} keys.'
            );
        }
    }

    return findLidarSource(lat, lon);
}
