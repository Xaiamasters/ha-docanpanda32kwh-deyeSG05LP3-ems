export default class LZWDecoder extends BaseDecoder {
    /** @param {ArrayBuffer} buffer */
    decodeBlock(buffer: ArrayBuffer): ArrayBuffer;
}
import BaseDecoder from './basedecoder.js';
//# sourceMappingURL=lzw.d.ts.map