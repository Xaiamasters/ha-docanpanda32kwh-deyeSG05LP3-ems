export default function create(): Worker;
//# sourceMappingURL=create.d.ts.map