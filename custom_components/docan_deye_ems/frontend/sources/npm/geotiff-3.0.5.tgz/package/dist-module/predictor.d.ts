/**
 * @param {ArrayBufferLike} block
 * @param {number} predictor
 * @param {number} width
 * @param {number} height
 * @param {number[]} bitsPerSample
 * @param {number} planarConfiguration
 * @returns
 */
export function applyPredictor(block: ArrayBufferLike, predictor: number, width: number, height: number, bitsPerSample: number[], planarConfiguration: number): ArrayBufferLike;
//# sourceMappingURL=predictor.d.ts.map