/**
 * @param {string} url
 * @param {RemoteSourceOptions & BlockedSourceOptions & { credentials?: RequestCredentials}} [param1]
 * @returns {BaseSource}
 */
export function makeFetchSource(url: string, { headers, credentials, maxRanges, allowFullFile, ...blockOptions }?: RemoteSourceOptions & BlockedSourceOptions & {
    credentials?: RequestCredentials;
}): BaseSource;
/**
 * @param {string} url
 * @param {RemoteSourceOptions & BlockedSourceOptions} [param1]
 * @returns {BaseSource}
 */
export function makeXHRSource(url: string, { headers, maxRanges, allowFullFile, ...blockOptions }?: RemoteSourceOptions & BlockedSourceOptions): BaseSource;
/**
 * @param {string} url
 * @param {RemoteSourceOptions & BlockedSourceOptions} [param1]
 * @returns {BaseSource}
 */
export function makeHttpSource(url: string, { headers, maxRanges, allowFullFile, ...blockOptions }?: RemoteSourceOptions & BlockedSourceOptions): BaseSource;
/**
 * @param {import("../geotiff.js").BaseClient} client
 * @param {RemoteSourceOptions & BlockedSourceOptions} [param1]
 * @returns {BaseSource}
 */
export function makeCustomSource(client: import("../geotiff.js").BaseClient, { headers, maxRanges, allowFullFile, ...blockOptions }?: RemoteSourceOptions & BlockedSourceOptions): BaseSource;
/**
 *
 * @param {string} url
 * @param {RemoteSourceOptions} options
 */
export function makeRemoteSource(url: string, { forceXHR, ...clientOptions }?: RemoteSourceOptions): BaseSource;
import type { RemoteSourceOptions } from '../geotiff.js';
import type { BlockedSourceOptions } from '../geotiff.js';
import { BaseSource } from './basesource.js';
//# sourceMappingURL=remote.d.ts.map