/** @module geotiffimage */
import { getFloat16 } from '@petamoriken/float16';
// @ts-expect-error
import getAttribute from 'xml-utils/get-attribute'; // eslint-disable-line import/extensions
// @ts-expect-error
import findTagsByName from 'xml-utils/find-tags-by-name'; // eslint-disable-line import/extensions
import { photometricInterpretations, ExtraSamplesValues } from './globals.js';
import { fromWhiteIsZero, fromBlackIsZero, fromPalette, fromCMYK, fromYCbCr, fromCIELab } from './rgb.js';
import { getDecoder, getDecoderParameters } from './compression/index.js';
import { resample, resampleInterleaved } from './resample.js';
/** @import {DecoderWorker, TypedArray} from "./geotiff.js" */
/** @import {ReadRasterResult} from "./geotiff.js" */
/** @import {ReadRastersOptions} from "./geotiff.js" */
/** @import {ReadRGBOptions} from "./geotiff.js" */
/**
 * @param {Array<number>|TypedArray} array
 * @param {number} start
 * @param {number} end
 * @returns {number}
 */
function sum(array, start, end) {
    let s = 0;
    for (let i = start; i < end; ++i) {
        s += array[i];
    }
    return s;
}
/**
 * @param {1|2|3} format
 * @param {number} bitsPerSample
 * @param {number|ArrayBufferLike} sizeOrData
 * @returns {TypedArray}
 */
function arrayForType(format, bitsPerSample, sizeOrData) {
    let TypedArrayConstructor;
    switch (format) {
        case 1: // unsigned integer data
            if (bitsPerSample <= 8) {
                TypedArrayConstructor = Uint8Array;
            }
            else if (bitsPerSample <= 16) {
                TypedArrayConstructor = Uint16Array;
            }
            else if (bitsPerSample <= 32) {
                TypedArrayConstructor = Uint32Array;
            }
            break;
        case 2: // twos complement signed integer data
            if (bitsPerSample === 8) {
                TypedArrayConstructor = Int8Array;
            }
            else if (bitsPerSample === 16) {
                TypedArrayConstructor = Int16Array;
            }
            else if (bitsPerSample === 32) {
                TypedArrayConstructor = Int32Array;
            }
            break;
        case 3: // floating point data
            switch (bitsPerSample) {
                case 16:
                case 32:
                    TypedArrayConstructor = Float32Array;
                    break;
                case 64:
                    TypedArrayConstructor = Float64Array;
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }
    if (TypedArrayConstructor) {
        if (typeof sizeOrData === 'number') {
            return new TypedArrayConstructor(sizeOrData);
        }
        else if (sizeOrData instanceof ArrayBuffer) {
            return new TypedArrayConstructor(sizeOrData);
        }
    }
    throw Error('Unsupported data format/bitsPerSample');
}
/**
 * @param {1|2|3} format
 * @param {number} bitsPerSample
 * @returns {boolean}
 */
function needsNormalization(format, bitsPerSample) {
    if ((format === 1 || format === 2) && bitsPerSample <= 32 && bitsPerSample % 8 === 0) {
        return false;
    }
    else if (format === 3 && (bitsPerSample === 16 || bitsPerSample === 32 || bitsPerSample === 64)) {
        return false;
    }
    return true;
}
/**
 * @param {ArrayBufferLike} inBuffer
 * @param {1|2|3} format
 * @param {1|2} planarConfiguration
 * @param {number} samplesPerPixel
 * @param {number} bitsPerSample
 * @param {number} tileWidth
 * @param {number} tileHeight
 * @returns {ArrayBufferLike}
 */
function normalizeArray(inBuffer, format, planarConfiguration, samplesPerPixel, bitsPerSample, tileWidth, tileHeight) {
    // const inByteArray = new Uint8Array(inBuffer);
    const view = new DataView(inBuffer);
    const outSize = planarConfiguration === 2
        ? tileHeight * tileWidth
        : tileHeight * tileWidth * samplesPerPixel;
    const samplesToTransfer = planarConfiguration === 2
        ? 1 : samplesPerPixel;
    const outArray = arrayForType(format, bitsPerSample, outSize);
    // let pixel = 0;
    const bitMask = parseInt('1'.repeat(bitsPerSample), 2);
    if (format === 1) { // unsigned integer
        // translation of https://github.com/OSGeo/gdal/blob/master/gdal/frmts/gtiff/geotiff.cpp#L7337
        let pixelBitSkip;
        // let sampleBitOffset = 0;
        if (planarConfiguration === 1) {
            pixelBitSkip = samplesPerPixel * bitsPerSample;
            // sampleBitOffset = (samplesPerPixel - 1) * bitsPerSample;
        }
        else {
            pixelBitSkip = bitsPerSample;
        }
        // Bits per line rounds up to next byte boundary.
        let bitsPerLine = tileWidth * pixelBitSkip;
        if ((bitsPerLine & 7) !== 0) {
            bitsPerLine = (bitsPerLine + 7) & (~7);
        }
        for (let y = 0; y < tileHeight; ++y) {
            const lineBitOffset = y * bitsPerLine;
            for (let x = 0; x < tileWidth; ++x) {
                const pixelBitOffset = lineBitOffset + (x * samplesToTransfer * bitsPerSample);
                for (let i = 0; i < samplesToTransfer; ++i) {
                    const bitOffset = pixelBitOffset + (i * bitsPerSample);
                    const outIndex = (((y * tileWidth) + x) * samplesToTransfer) + i;
                    const byteOffset = Math.floor(bitOffset / 8);
                    const innerBitOffset = bitOffset % 8;
                    if (innerBitOffset + bitsPerSample <= 8) {
                        outArray[outIndex] = (view.getUint8(byteOffset) >> (8 - bitsPerSample) - innerBitOffset) & bitMask;
                    }
                    else if (innerBitOffset + bitsPerSample <= 16) {
                        outArray[outIndex] = (view.getUint16(byteOffset) >> (16 - bitsPerSample) - innerBitOffset) & bitMask;
                    }
                    else if (innerBitOffset + bitsPerSample <= 24) {
                        const raw = (view.getUint16(byteOffset) << 8) | (view.getUint8(byteOffset + 2));
                        outArray[outIndex] = (raw >> (24 - bitsPerSample) - innerBitOffset) & bitMask;
                    }
                    else {
                        outArray[outIndex] = (view.getUint32(byteOffset) >> (32 - bitsPerSample) - innerBitOffset) & bitMask;
                    }
                    // let outWord = 0;
                    // for (let bit = 0; bit < bitsPerSample; ++bit) {
                    //   if (inByteArray[bitOffset >> 3]
                    //     & (0x80 >> (bitOffset & 7))) {
                    //     outWord |= (1 << (bitsPerSample - 1 - bit));
                    //   }
                    //   ++bitOffset;
                    // }
                    // outArray[outIndex] = outWord;
                    // outArray[pixel] = outWord;
                    // pixel += 1;
                }
                // bitOffset = bitOffset + pixelBitSkip - bitsPerSample;
            }
        }
    }
    else if (format === 3) { // floating point
        // Float16 is handled elsewhere
        // normalize 16/24 bit floats to 32 bit floats in the array
        // console.time();
        // if (bitsPerSample === 16) {
        //   for (let byte = 0, outIndex = 0; byte < inBuffer.byteLength; byte += 2, ++outIndex) {
        //     outArray[outIndex] = getFloat16(view, byte);
        //   }
        // }
        // console.timeEnd()
    }
    return outArray.buffer;
}
/**
 * GeoTIFF sub-file image.
 */
class GeoTIFFImage {
    /**
     * @constructor
     * @param {import("./imagefiledirectory.js").ImageFileDirectory} fileDirectory The parsed file directory
     * @param {Boolean} littleEndian Whether the file is encoded in little or big endian
     * @param {Boolean} cache Whether or not decoded tiles shall be cached
     * @param {import('./source/basesource.js').BaseSource} source The datasource to read from
     */
    constructor(fileDirectory, littleEndian, cache, source) {
        this.fileDirectory = fileDirectory;
        this.littleEndian = littleEndian;
        /** @type {Array<Promise<ArrayBufferLike>>|null} */
        this.tiles = cache ? [] : null;
        this.isTiled = !fileDirectory.hasTag('StripOffsets');
        const planarConfiguration = fileDirectory.getValue('PlanarConfiguration') ?? 1;
        if (planarConfiguration !== 1 && planarConfiguration !== 2) {
            throw new Error('Invalid planar configuration.');
        }
        /** @type {1 | 2} */
        this.planarConfiguration = planarConfiguration;
        this.source = source;
    }
    /**
     * Returns the associated parsed file directory.
     * @returns {import("./imagefiledirectory.js").ImageFileDirectory} the parsed file directory
     */
    getFileDirectory() {
        return this.fileDirectory;
    }
    /**
     * Returns the associated parsed geo keys.
     * @returns {Partial<Record<import('./globals.js').GeoKeyName, *>>|null} the parsed geo keys
     */
    getGeoKeys() {
        return this.fileDirectory.parseGeoKeyDirectory();
    }
    /**
     * Returns the width of the image.
     * @returns {Number} the width of the image
     */
    getWidth() {
        return this.fileDirectory.getValue('ImageWidth') || 0;
    }
    /**
     * Returns the height of the image.
     * @returns {Number} the height of the image
     */
    getHeight() {
        return this.fileDirectory.getValue('ImageLength') || 0;
    }
    /**
     * Returns the number of samples per pixel.
     * @returns {number} the number of samples per pixel
     */
    getSamplesPerPixel() {
        return this.fileDirectory.getValue('SamplesPerPixel') ?? 1;
    }
    /**
     * Returns the width of each tile.
     * @returns {number} the width of each tile
     */
    getTileWidth() {
        return this.isTiled ? (this.fileDirectory.getValue('TileWidth') || 0) : this.getWidth();
    }
    /**
     * Returns the height of each tile.
     * @returns {number} the height of each tile
     */
    getTileHeight() {
        if (this.isTiled) {
            return this.fileDirectory.getValue('TileLength') || 0;
        }
        const rowsPerStrip = this.fileDirectory.hasTag('RowsPerStrip') && this.fileDirectory.getValue('RowsPerStrip');
        if (rowsPerStrip) {
            return Math.min(rowsPerStrip, this.getHeight());
        }
        return this.getHeight();
    }
    getBlockWidth() {
        return this.getTileWidth();
    }
    /**
     * @param {number} y
     * @returns {number}
     */
    getBlockHeight(y) {
        if (this.isTiled || (y + 1) * this.getTileHeight() <= this.getHeight()) {
            return this.getTileHeight();
        }
        else {
            return this.getHeight() - (y * this.getTileHeight());
        }
    }
    /**
     * Calculates the number of bytes for each pixel across all samples. Only full
     * bytes are supported, an exception is thrown when this is not the case.
     * @returns {Number} the bytes per pixel
     */
    getBytesPerPixel() {
        let bytes = 0;
        // this is a short list, so we assume this is already loaded
        const bitsPerSample = this.fileDirectory.getValue('BitsPerSample') || [];
        for (let i = 0; i < bitsPerSample.length; ++i) {
            bytes += this.getSampleByteSize(i);
        }
        return bytes;
    }
    /**
     * @param {number} i
     * @returns {number}
     */
    getSampleByteSize(i) {
        const bitsPerSample = this.fileDirectory.getValue('BitsPerSample') || [];
        if (i >= bitsPerSample.length) {
            throw new RangeError(`Sample index ${i} is out of range.`);
        }
        return Math.ceil(bitsPerSample[i] / 8);
    }
    /**
     * @param {number} sampleIndex
     * @returns {(this: DataView, byteOffset: number, littleEndian: boolean) => number}
     */
    getReaderForSample(sampleIndex) {
        const sampleFormat = this.fileDirectory.getValue('SampleFormat');
        const format = sampleFormat
            ? sampleFormat[sampleIndex] : 1;
        const bitsPerSample = (this.fileDirectory.getValue('BitsPerSample') || [])[sampleIndex];
        switch (format) {
            case 1: // unsigned integer data
                if (bitsPerSample <= 8) {
                    return DataView.prototype.getUint8;
                }
                else if (bitsPerSample <= 16) {
                    return DataView.prototype.getUint16;
                }
                else if (bitsPerSample <= 32) {
                    return DataView.prototype.getUint32;
                }
                break;
            case 2: // twos complement signed integer data
                if (bitsPerSample <= 8) {
                    return DataView.prototype.getInt8;
                }
                else if (bitsPerSample <= 16) {
                    return DataView.prototype.getInt16;
                }
                else if (bitsPerSample <= 32) {
                    return DataView.prototype.getInt32;
                }
                break;
            case 3:
                switch (bitsPerSample) {
                    case 16:
                        return function (offset, littleEndian) {
                            return getFloat16(this, offset, littleEndian);
                        };
                    case 32:
                        return DataView.prototype.getFloat32;
                    case 64:
                        return DataView.prototype.getFloat64;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
        throw Error('Unsupported data format/bitsPerSample');
    }
    getSampleFormat(sampleIndex = 0) {
        const sampleFormat = this.fileDirectory.getValue('SampleFormat');
        return sampleFormat ? sampleFormat[sampleIndex] : 1;
    }
    getBitsPerSample(sampleIndex = 0) {
        const bitsPerSample = this.fileDirectory.getValue('BitsPerSample');
        return bitsPerSample ? bitsPerSample[sampleIndex] : 0;
    }
    /**
     * @param {number} sampleIndex
     * @param {number|ArrayBufferLike} sizeOrData
     * @returns {TypedArray}
     */
    getArrayForSample(sampleIndex, sizeOrData) {
        const format = /** @type {1|2|3} */ (this.getSampleFormat(sampleIndex));
        const bitsPerSample = this.getBitsPerSample(sampleIndex);
        return arrayForType(format, bitsPerSample, sizeOrData);
    }
    /**
     * Returns the decoded strip or tile.
     * @param {Number} x the strip or tile x-offset
     * @param {Number} y the tile y-offset (0 for stripped images)
     * @param {Number} sample the sample to get for separated samples
     * @param {DecoderWorker|import("./geotiff.js").BaseDecoder} poolOrDecoder the decoder or decoder pool
     * @param {AbortSignal} [signal] An AbortSignal that may be signalled if the request is
     *                               to be aborted
     * @returns {Promise.<{x: number, y: number, sample: number, data: ArrayBufferLike}>} the decoded strip or tile
     */
    async getTileOrStrip(x, y, sample, poolOrDecoder, signal) {
        const numTilesPerRow = Math.ceil(this.getWidth() / this.getTileWidth());
        const numTilesPerCol = Math.ceil(this.getHeight() / this.getTileHeight());
        let index;
        const { tiles } = this;
        if (this.planarConfiguration === 1) {
            index = (y * numTilesPerRow) + x;
        }
        else if (this.planarConfiguration === 2) {
            index = (sample * numTilesPerRow * numTilesPerCol) + (y * numTilesPerRow) + x;
        }
        if (index === undefined) {
            throw new Error('Could not determine tile or strip index.');
        }
        let offset;
        let byteCount;
        if (this.isTiled) {
            offset = Number(await this.fileDirectory.loadValueIndexed('TileOffsets', index));
            byteCount = Number(await this.fileDirectory.loadValueIndexed('TileByteCounts', index));
        }
        else {
            offset = Number(await this.fileDirectory.loadValueIndexed('StripOffsets', index));
            byteCount = Number(await this.fileDirectory.loadValueIndexed('StripByteCounts', index));
        }
        if (byteCount === 0) {
            const nPixels = this.getBlockHeight(y) * this.getTileWidth();
            const bytesPerPixel = (this.planarConfiguration === 2) ? this.getSampleByteSize(sample) : this.getBytesPerPixel();
            const data = new ArrayBuffer(nPixels * bytesPerPixel);
            const view = this.getArrayForSample(sample, data);
            view.fill(this.getGDALNoData() || 0);
            return { x, y, sample, data };
        }
        const slice = (await this.source.fetch([{ offset, length: byteCount }], signal))[0];
        let request;
        if (tiles === null || !tiles[index]) {
            // resolve each request by potentially applying array normalization
            request = (async () => {
                let data = await poolOrDecoder.decode(slice);
                const sampleFormat = /** @type {1|2|3} */ (this.getSampleFormat());
                const bitsPerSample = this.getBitsPerSample();
                if (needsNormalization(sampleFormat, bitsPerSample)) {
                    data = normalizeArray(data, sampleFormat, this.planarConfiguration, this.getSamplesPerPixel(), bitsPerSample, this.getTileWidth(), this.getBlockHeight(y));
                }
                return data;
            })();
            // set the cache
            if (tiles !== null) {
                tiles[index] = request;
            }
        }
        else {
            // get from the cache
            request = tiles[index];
        }
        // cache the tile request
        return { x, y, sample, data: await request };
    }
    /**
     * Internal read function.
     * @private
     * @param {Array<number>} imageWindow The image window in pixel coordinates
     * @param {Array<number>} samples The selected samples (0-based indices)
     * @param {TypedArray|TypedArray[]} valueArrays The array(s) to write into
     * @param {boolean|undefined} interleave Whether or not to write in an interleaved manner
     * @param {DecoderWorker|import("./geotiff.js").BaseDecoder} poolOrDecoder the decoder or decoder pool
     * @param {number} [width] the width of window to be read into
     * @param {number} [height] the height of window to be read into
     * @param {string} [resampleMethod] the resampling method to be used when interpolating
     * @param {AbortSignal} [signal] An AbortSignal that may be signalled if the request is
     *                               to be aborted
     * @returns {Promise<ReadRasterResult>}
     */
    async _readRaster(imageWindow, samples, valueArrays, interleave, poolOrDecoder, width, height, resampleMethod, signal) {
        const tileWidth = this.getTileWidth();
        const tileHeight = this.getTileHeight();
        const imageWidth = this.getWidth();
        const imageHeight = this.getHeight();
        const minXTile = Math.max(Math.floor(imageWindow[0] / tileWidth), 0);
        const maxXTile = Math.min(Math.ceil(imageWindow[2] / tileWidth), Math.ceil(imageWidth / tileWidth));
        const minYTile = Math.max(Math.floor(imageWindow[1] / tileHeight), 0);
        const maxYTile = Math.min(Math.ceil(imageWindow[3] / tileHeight), Math.ceil(imageHeight / tileHeight));
        const windowWidth = imageWindow[2] - imageWindow[0];
        let bytesPerPixel = this.getBytesPerPixel();
        /** @type {Array<number>} */
        const srcSampleOffsets = [];
        /** @type {Array<(this: DataView, byteOffset: number, littleEndian: boolean) => number>} */
        const sampleReaders = [];
        for (let i = 0; i < samples.length; ++i) {
            if (this.planarConfiguration === 1) {
                const bitsPerSample = await this.fileDirectory.loadValue('BitsPerSample');
                if (typeof bitsPerSample !== 'object') {
                    throw new Error('Expected BitsPerSample to be an array or typed array.');
                }
                srcSampleOffsets.push(sum(bitsPerSample, 0, samples[i]) / 8);
            }
            else {
                srcSampleOffsets.push(0);
            }
            sampleReaders.push(this.getReaderForSample(samples[i]));
        }
        const promises = [];
        const { littleEndian } = this;
        for (let yTile = minYTile; yTile < maxYTile; ++yTile) {
            for (let xTile = minXTile; xTile < maxXTile; ++xTile) {
                let getPromise;
                if (this.planarConfiguration === 1) {
                    getPromise = this.getTileOrStrip(xTile, yTile, 0, poolOrDecoder, signal);
                }
                for (let sampleIndex = 0; sampleIndex < samples.length; ++sampleIndex) {
                    const si = sampleIndex;
                    const sample = samples[sampleIndex];
                    if (this.planarConfiguration === 2) {
                        bytesPerPixel = this.getSampleByteSize(sample);
                        getPromise = this.getTileOrStrip(xTile, yTile, sample, poolOrDecoder, signal);
                    }
                    if (!getPromise) {
                        throw new Error('Could not get tile or strip data.');
                    }
                    const promise = getPromise.then((tile) => {
                        const buffer = tile.data;
                        const dataView = new DataView(buffer);
                        const blockHeight = this.getBlockHeight(tile.y);
                        const firstLine = tile.y * tileHeight;
                        const firstCol = tile.x * tileWidth;
                        const lastLine = firstLine + blockHeight;
                        const lastCol = (tile.x + 1) * tileWidth;
                        const reader = sampleReaders[si];
                        const ymax = Math.min(blockHeight, blockHeight - (lastLine - imageWindow[3]), imageHeight - firstLine);
                        const xmax = Math.min(tileWidth, tileWidth - (lastCol - imageWindow[2]), imageWidth - firstCol);
                        for (let y = Math.max(0, imageWindow[1] - firstLine); y < ymax; ++y) {
                            for (let x = Math.max(0, imageWindow[0] - firstCol); x < xmax; ++x) {
                                const pixelOffset = ((y * tileWidth) + x) * bytesPerPixel;
                                const value = reader.call(dataView, pixelOffset + srcSampleOffsets[si], littleEndian);
                                let windowCoordinate;
                                if (interleave) {
                                    windowCoordinate = ((y + firstLine - imageWindow[1]) * windowWidth * samples.length)
                                        + ((x + firstCol - imageWindow[0]) * samples.length)
                                        + si;
                                    valueArrays[windowCoordinate] = value;
                                }
                                else {
                                    windowCoordinate = ((y + firstLine - imageWindow[1]) * windowWidth) + x + firstCol - imageWindow[0];
                                    /** @type {TypedArray} */ (valueArrays[si])[windowCoordinate] = value;
                                }
                            }
                        }
                    });
                    promises.push(promise);
                }
            }
        }
        await Promise.all(promises);
        if ((width && (imageWindow[2] - imageWindow[0]) !== width)
            || (height && (imageWindow[3] - imageWindow[1]) !== height)) {
            let resampled;
            if (interleave) {
                resampled = resampleInterleaved(
                /** @type {TypedArray} */ (valueArrays), imageWindow[2] - imageWindow[0], imageWindow[3] - imageWindow[1], 
                /** @type {number} */ (width), /** @type {number} */ (height), samples.length, resampleMethod);
            }
            else {
                resampled = resample(
                /** @type {TypedArray[]} */ (valueArrays), imageWindow[2] - imageWindow[0], imageWindow[3] - imageWindow[1], 
                /** @type {number} */ (width), /** @type {number} */ (height), resampleMethod);
            }
            const resampledWithDimensions = /** @type {ReadRasterResult} */ (resampled);
            resampledWithDimensions.width = width ?? imageWindow[2] - imageWindow[0];
            resampledWithDimensions.height = height ?? imageWindow[3] - imageWindow[1];
            return resampledWithDimensions;
        }
        const valueArraysWithDimensions = /** @type {ReadRasterResult} */ (valueArrays);
        valueArraysWithDimensions.width = width || imageWindow[2] - imageWindow[0];
        valueArraysWithDimensions.height = height || imageWindow[3] - imageWindow[1];
        return valueArraysWithDimensions;
    }
    /**
     * @overload
     * @param {ReadRastersOptions & {interleave: true}} options optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayWithDimensions>} the decoded arrays as a promise
     */
    /**
     * @overload
     * @param {ReadRastersOptions & {interleave: false}} options optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayArrayWithDimensions>} the decoded arrays as a promise
     */
    /**
     * @overload
     * @param {ReadRastersOptions & {interleave: boolean}} options optional parameters
     * @returns {Promise<ReadRasterResult>} the decoded arrays as a promise
     */
    /**
     * @overload
     * @param {ReadRastersOptions} [options={}] optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayArrayWithDimensions>} the decoded arrays as a promise
     */
    /**
     * Reads raster data from the image. This function reads all selected samples
     * into separate arrays of the correct type for that sample or into a single
     * combined array when `interleave` is set. When provided, only a subset
     * of the raster is read for each sample.
     *
     * @param {ReadRastersOptions} [options={}] optional parameters
     * @returns {Promise<ReadRasterResult>} the decoded arrays as a promise
     */
    async readRasters(options = {}) {
        const { window: wnd, samples = [], pool = null, width, height, resampleMethod, fillValue, signal, } = options;
        const interleave = 'interleave' in options && options.interleave;
        const imageWindow = wnd || [0, 0, this.getWidth(), this.getHeight()];
        // check parameters
        if (imageWindow[0] > imageWindow[2] || imageWindow[1] > imageWindow[3]) {
            throw new Error('Invalid subsets');
        }
        const imageWindowWidth = imageWindow[2] - imageWindow[0];
        const imageWindowHeight = imageWindow[3] - imageWindow[1];
        const numPixels = imageWindowWidth * imageWindowHeight;
        const samplesPerPixel = this.getSamplesPerPixel();
        if (!samples || !samples.length) {
            for (let i = 0; i < samplesPerPixel; ++i) {
                samples.push(i);
            }
        }
        else {
            for (let i = 0; i < samples.length; ++i) {
                if (samples[i] >= samplesPerPixel) {
                    return Promise.reject(new RangeError(`Invalid sample index '${samples[i]}'.`));
                }
            }
        }
        /** @type {TypedArray|TypedArray[]} */
        let valueArrays;
        if (interleave) {
            const { fileDirectory } = this;
            const sampleFormat = fileDirectory.getValue('SampleFormat');
            const format = sampleFormat
                ? Math.max.apply(null, Array.from(sampleFormat)) : 1;
            if (format !== 1 && format !== 2 && format !== 3) {
                throw new Error('Unsupported sample format for interleaved data. Must be 1, 2, or 3.');
            }
            const bitsPerSample_ = fileDirectory.getValue('BitsPerSample');
            const bitsPerSample = bitsPerSample_
                ? Math.max.apply(null, Array.from(bitsPerSample_)) : 8;
            valueArrays = arrayForType(format, bitsPerSample, numPixels * samples.length);
            if (fillValue) {
                if (Array.isArray(fillValue)) {
                    throw new Error('When reading interleaved data, fillValue must be a single number.');
                }
                valueArrays.fill(fillValue);
            }
        }
        else {
            valueArrays = [];
            for (let i = 0; i < samples.length; ++i) {
                const valueArray = this.getArrayForSample(samples[i], numPixels);
                if (Array.isArray(fillValue) && i < fillValue.length) {
                    valueArray.fill(fillValue[i]);
                }
                else if (fillValue && !Array.isArray(fillValue)) {
                    valueArray.fill(fillValue);
                }
                valueArrays.push(valueArray);
            }
        }
        const compression = this.fileDirectory.getValue('Compression') || 1;
        const decoderParameters = await getDecoderParameters(compression, this.fileDirectory);
        const poolOrDecoder = pool
            ? pool.bindParameters(compression, decoderParameters)
            : await getDecoder(compression, decoderParameters);
        const result = await this._readRaster(imageWindow, samples, valueArrays, interleave, poolOrDecoder, width, height, resampleMethod, signal);
        return result;
    }
    /**
     * @overload
     * @param {ReadRGBOptions & {interleave: true}} options optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayWithDimensions>} the RGB array as a Promise
     */
    /**
     * @overload
     * @param {ReadRGBOptions & {interleave: false}} options optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayArrayWithDimensions>} the RGB array as a Promise
     */
    /**
     * @overload
     * @param {ReadRGBOptions & {interleave: boolean}} options optional parameters
     * @returns {Promise<ReadRasterResult>} the RGB array as a Promise
     */
    /**
     * @overload
     * @param {ReadRGBOptions} [options={}] optional parameters
     * @returns {Promise<import("./geotiff.js").TypedArrayArrayWithDimensions>} the RGB array as a Promise
     */
    /**
     * Reads raster data from the image as RGB.
     * Colorspaces other than RGB will be transformed to RGB, color maps expanded.
     * When no other method is applicable, the first sample is used to produce a
     * grayscale image.
     * When provided, only a subset of the raster is read for each sample.
     *
     * @param {ReadRGBOptions} [options] optional parameters
     * @returns {Promise<ReadRasterResult>} the RGB array as a Promise
     */
    async readRGB(options = {}) {
        const { window, pool = null, width, height, resampleMethod, enableAlpha = false, signal } = options;
        const interleave = ('interleave' in options && options.interleave) ?? false;
        const imageWindow = window || [0, 0, this.getWidth(), this.getHeight()];
        // check parameters
        if (imageWindow[0] > imageWindow[2] || imageWindow[1] > imageWindow[3]) {
            throw new Error('Invalid subsets');
        }
        const pi = this.fileDirectory.getValue('PhotometricInterpretation');
        if (pi === photometricInterpretations.RGB) {
            let s = [0, 1, 2];
            const extraSamples = this.fileDirectory.getValue('ExtraSamples');
            if (extraSamples && extraSamples[0] !== ExtraSamplesValues.Unspecified && enableAlpha) {
                s = [];
                const bitsPerSample = this.fileDirectory.getValue('BitsPerSample') || [];
                for (let i = 0; i < bitsPerSample.length; i += 1) {
                    s.push(i);
                }
            }
            return this.readRasters({
                window,
                interleave,
                samples: s,
                pool,
                width,
                height,
                resampleMethod,
                signal,
            });
        }
        let samples;
        switch (pi) {
            case photometricInterpretations.WhiteIsZero:
            case photometricInterpretations.BlackIsZero:
            case photometricInterpretations.Palette:
                samples = [0];
                break;
            case photometricInterpretations.CMYK:
                samples = [0, 1, 2, 3];
                break;
            case photometricInterpretations.YCbCr:
            case photometricInterpretations.CIELab:
                samples = [0, 1, 2];
                break;
            default:
                throw new Error('Invalid or unsupported photometric interpretation.');
        }
        const subOptions = {
            window: imageWindow,
            /** @type {true} */
            interleave: true,
            samples,
            pool,
            width,
            height,
            resampleMethod,
            signal,
        };
        const { fileDirectory } = this;
        const raster = await this.readRasters(subOptions);
        const max = 2 ** this.getBitsPerSample(0);
        let data;
        switch (pi) {
            case photometricInterpretations.WhiteIsZero:
                data = fromWhiteIsZero(raster, max);
                break;
            case photometricInterpretations.BlackIsZero:
                data = fromBlackIsZero(raster, max);
                break;
            case photometricInterpretations.Palette:
                data = fromPalette(raster, /** @type {Uint16Array} */ (await fileDirectory.loadValue('ColorMap')));
                break;
            case photometricInterpretations.CMYK:
                data = fromCMYK(raster);
                break;
            case photometricInterpretations.YCbCr:
                data = fromYCbCr(raster);
                break;
            case photometricInterpretations.CIELab:
                data = fromCIELab(raster);
                break;
            default:
                throw new Error('Unsupported photometric interpretation.');
        }
        // if non-interleaved data is requested, we must split the channels
        // into their respective arrays
        if (!interleave) {
            const red = new Uint8Array(data.length / 3);
            const green = new Uint8Array(data.length / 3);
            const blue = new Uint8Array(data.length / 3);
            for (let i = 0, j = 0; i < data.length; i += 3, ++j) {
                red[j] = data[i];
                green[j] = data[i + 1];
                blue[j] = data[i + 2];
            }
            data = [red, green, blue];
        }
        const dataWithDimensions = /** @type {import("./geotiff.js").ReadRasterResult} */ (data);
        dataWithDimensions.width = raster.width;
        dataWithDimensions.height = raster.height;
        return dataWithDimensions;
    }
    /**
     * Returns an array of tiepoints.
     * @returns {Promise<Array<{i: number, j: number, k: number, x: number, y: number, z: number}>>} the tiepoints
     */
    async getTiePoints() {
        if (!this.fileDirectory.hasTag('ModelTiepoint')) {
            return [];
        }
        const modelTiePoint = await this.fileDirectory.loadValue('ModelTiepoint');
        if (typeof modelTiePoint !== 'object') {
            throw new Error('Expected ModelTiepoint to be an array or typed array.');
        }
        const tiePoints = [];
        for (let i = 0; i < modelTiePoint.length; i += 6) {
            tiePoints.push({
                i: modelTiePoint[i],
                j: modelTiePoint[i + 1],
                k: modelTiePoint[i + 2],
                x: modelTiePoint[i + 3],
                y: modelTiePoint[i + 4],
                z: modelTiePoint[i + 5],
            });
        }
        return tiePoints;
    }
    /**
     * Returns the parsed GDAL metadata items.
     *
     * If sample is passed to null, dataset-level metadata will be returned.
     * Otherwise only metadata specific to the provided sample will be returned.
     *
     * @param {number|null} [sample=null] The sample index.
     * @returns {Promise<Record<string, unknown>|null>} The GDAL metadata items
     */
    async getGDALMetadata(sample = null) {
        /** @type {Record<string, unknown>} */
        const metadata = {};
        if (!this.fileDirectory.hasTag('GDAL_METADATA')) {
            return null;
        }
        const string = await this.fileDirectory.loadValue('GDAL_METADATA');
        /** @type {Array<{inner: unknown}>} */
        let items = findTagsByName(string, 'Item');
        if (sample === null) {
            items = items.filter((item) => getAttribute(item, 'sample') === undefined);
        }
        else {
            items = items.filter((item) => Number(getAttribute(item, 'sample')) === sample);
        }
        for (let i = 0; i < items.length; ++i) {
            const item = items[i];
            metadata[getAttribute(item, 'name')] = item.inner;
        }
        return metadata;
    }
    /**
     * Returns the GDAL nodata value
     * @returns {number|null}
     */
    getGDALNoData() {
        const string = this.fileDirectory.hasTag('GDAL_NODATA') && this.fileDirectory.getValue('GDAL_NODATA');
        if (!string) {
            return null;
        }
        return Number(string.substring(0, string.length - 1));
    }
    /**
     * Returns the image origin as a XYZ-vector. When the image has no affine
     * transformation, then an exception is thrown.
     * @returns {Array<number>} The origin as a vector
     */
    getOrigin() {
        const tiePoints = this.fileDirectory.getValue('ModelTiepoint');
        const modelTransformation = this.fileDirectory.getValue('ModelTransformation');
        if (tiePoints && tiePoints.length === 6) {
            return [
                tiePoints[3],
                tiePoints[4],
                tiePoints[5],
            ];
        }
        if (modelTransformation) {
            return [
                modelTransformation[3],
                modelTransformation[7],
                modelTransformation[11],
            ];
        }
        throw new Error('The image does not have an affine transformation.');
    }
    /**
     * Returns the image resolution as a XYZ-vector. When the image has no affine
     * transformation, then an exception is thrown.
     * @param {GeoTIFFImage|null} [referenceImage=null] A reference image to calculate the resolution from
     *                                             in cases when the current image does not have the
     *                                             required tags on its own.
     * @returns {Array<number>} The resolution as a vector
     */
    getResolution(referenceImage = null) {
        const modelPixelScale = this.fileDirectory.getValue('ModelPixelScale');
        const modelTransformation = this.fileDirectory.getValue('ModelTransformation');
        if (modelPixelScale) {
            return [
                modelPixelScale[0],
                -modelPixelScale[1],
                modelPixelScale[2],
            ];
        }
        if (modelTransformation) {
            if (modelTransformation[1] === 0 && modelTransformation[4] === 0) {
                return [
                    modelTransformation[0],
                    -modelTransformation[5],
                    modelTransformation[10],
                ];
            }
            return [
                Math.sqrt((modelTransformation[0] * modelTransformation[0])
                    + (modelTransformation[4] * modelTransformation[4])),
                -Math.sqrt((modelTransformation[1] * modelTransformation[1])
                    + (modelTransformation[5] * modelTransformation[5])),
                modelTransformation[10]
            ];
        }
        if (referenceImage) {
            const [refResX, refResY, refResZ] = referenceImage.getResolution();
            return [
                refResX * referenceImage.getWidth() / this.getWidth(),
                refResY * referenceImage.getHeight() / this.getHeight(),
                refResZ * referenceImage.getWidth() / this.getWidth(),
            ];
        }
        throw new Error('The image does not have an affine transformation.');
    }
    /**
     * Returns whether or not the pixels of the image depict an area (or point).
     * @returns {Boolean} Whether the pixels are a point
     */
    pixelIsArea() {
        return this.getGeoKeys()?.GTRasterTypeGeoKey === 1;
    }
    /**
     * Returns the image bounding box as an array of 4 values: min-x, min-y,
     * max-x and max-y. When the image has no affine transformation, then an
     * exception is thrown.
     * @param {boolean} [tilegrid=false] If true return extent for a tilegrid
     *                                   without adjustment for ModelTransformation.
     * @returns {Array<number>} The bounding box
     */
    getBoundingBox(tilegrid = false) {
        const height = this.getHeight();
        const width = this.getWidth();
        const modelTransformation = this.fileDirectory.getValue('ModelTransformation');
        if (modelTransformation && !tilegrid) {
            const [a, b, , d, e, f, , h] = modelTransformation;
            const corners = [
                [0, 0],
                [0, height],
                [width, 0],
                [width, height],
            ];
            const projected = corners.map(([I, J]) => [
                d + (a * I) + (b * J),
                h + (e * I) + (f * J),
            ]);
            const xs = projected.map((pt) => pt[0]);
            const ys = projected.map((pt) => pt[1]);
            return [
                Math.min(...xs),
                Math.min(...ys),
                Math.max(...xs),
                Math.max(...ys),
            ];
        }
        else {
            const origin = this.getOrigin();
            const resolution = this.getResolution();
            const x1 = origin[0];
            const y1 = origin[1];
            const x2 = x1 + (resolution[0] * width);
            const y2 = y1 + (resolution[1] * height);
            return [
                Math.min(x1, x2),
                Math.min(y1, y2),
                Math.max(x1, x2),
                Math.max(y1, y2),
            ];
        }
    }
}
export default GeoTIFFImage;
//# sourceMappingURL=geotiffimage.js.map