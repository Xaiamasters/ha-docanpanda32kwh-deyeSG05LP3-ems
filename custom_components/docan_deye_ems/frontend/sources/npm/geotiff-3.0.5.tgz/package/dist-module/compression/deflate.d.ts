export default class DeflateDecoder extends BaseDecoder {
    /** @param {ArrayBuffer} buffer */
    decodeBlock(buffer: ArrayBuffer): ArrayBuffer;
}
import BaseDecoder from './basedecoder.js';
//# sourceMappingURL=deflate.d.ts.map