export class BlockedSource extends BaseSource {
    /**
     *
     * @param {BaseSource} source The underlying source that shall be blocked and cached
     * @param {object} options
     * @param {number} [options.blockSize]
     * @param {number} [options.cacheSize]
     */
    constructor(source: BaseSource, { blockSize, cacheSize }?: {
        blockSize?: number | undefined;
        cacheSize?: number | undefined;
    });
    source: BaseSource;
    blockSize: number;
    blockCache: QuickLRU<any, any>;
    /** @type {Map<number, Block>} */
    evictedBlocks: Map<number, Block>;
    blockRequests: Map<any, any>;
    blockIdsToFetch: Set<any>;
    abortedBlockIds: Set<any>;
    /**
     * @param {import("./basesource.js").Slice[]} slices
     * @param {AbortSignal} [signal]
     * @return {Promise<ArrayBuffer[]>}
     */
    fetch(slices: import("./basesource.js").Slice[], signal?: AbortSignal): Promise<ArrayBuffer[]>;
    /**
     * @param {AbortSignal} [signal]
     */
    fetchBlocks(signal?: AbortSignal): void;
    /**
     *
     * @param {Set<number>} blockIds
     * @returns {BlockGroup[]}
     */
    groupBlocks(blockIds: Set<number>): BlockGroup[];
    /**
     * @param {import("./basesource.js").Slice[]} slices
     * @param {Map<number, Block>} blocks
     * @returns {ArrayBuffer[]}
     */
    readSliceData(slices: import("./basesource.js").Slice[], blocks: Map<number, Block>): ArrayBuffer[];
}
import { BaseSource } from './basesource.js';
import QuickLRU from 'quick-lru';
declare class Block {
    /**
     *
     * @param {number} offset
     * @param {number} length
     * @param {ArrayBuffer} data
     */
    constructor(offset: number, length: number, data: ArrayBuffer);
    offset: number;
    length: number;
    data: ArrayBuffer;
    /**
     * @returns {number} the top byte border
     */
    get top(): number;
}
declare class BlockGroup {
    /**
     *
     * @param {number} offset
     * @param {number} length
     * @param {number[]} blockIds
     */
    constructor(offset: number, length: number, blockIds: number[]);
    offset: number;
    length: number;
    blockIds: number[];
}
export {};
//# sourceMappingURL=blockedsource.d.ts.map