export default class RawDecoder extends BaseDecoder {
    /** @param {ArrayBuffer} buffer */
    decodeBlock(buffer: ArrayBuffer): ArrayBuffer;
}
import BaseDecoder from './basedecoder.js';
//# sourceMappingURL=raw.d.ts.map