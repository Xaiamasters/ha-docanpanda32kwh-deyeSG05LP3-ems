/** @param {ArrayBuffer} arrayBuffer */
export function makeBufferSource(arrayBuffer: ArrayBuffer): ArrayBufferSource;
declare class ArrayBufferSource extends BaseSource {
    /**
     * @param {ArrayBuffer} arrayBuffer
     */
    constructor(arrayBuffer: ArrayBuffer);
    arrayBuffer: ArrayBuffer;
}
import { BaseSource } from './basesource.js';
export {};
//# sourceMappingURL=arraybuffer.d.ts.map