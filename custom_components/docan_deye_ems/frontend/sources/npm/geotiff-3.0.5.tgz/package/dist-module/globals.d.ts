/** @typedef {fieldTypeSizes[keyof typeof fieldTypeSizes]} FieldTypeSize */
/**
 * Get the byte size for a given field type.
 * @param {FieldType} fieldType The TIFF field type constant
 * @returns {number} The size in bytes
 * @throws {RangeError} If the field type is invalid
 */
export function getFieldTypeSize(fieldType: FieldType): number;
/**
 * Registers a new field tag
 * @param {number} tag the numeric tiff tag
 * @param {string} name the name of the tag that will be reported in the IFD
 * @param {keyof fieldTypes|number|undefined} type the tags data type
 * @param {Boolean} isArray whether the tag is an array
 * @param {boolean} [eager=false] whether to eagerly fetch deferred fields.
 *                                 When false (default), tags are loaded lazily on-demand.
 *                                 When true, all tags are loaded immediately during parsing.
 */
export function registerTag(tag: number, name: string, type: ("BYTE" | "ASCII" | "SHORT" | "LONG" | "RATIONAL" | "SBYTE" | "UNDEFINED" | "SSHORT" | "SLONG" | "SRATIONAL" | "FLOAT" | "DOUBLE" | "IFD" | "LONG8" | "SLONG8" | "IFD8") | number | undefined, isArray?: boolean, eager?: boolean): void;
/**
 * @param {number|string} tagIdentifier The field tag ID or name
 * @returns {number} the resolved tag ID
 */
export function resolveTag(tagIdentifier: number | string): number;
/**
 * @param {number|string} tagIdentifier The field tag ID or name
 * @returns {{ tag: number, name: string, type: string|number|undefined, isArray: boolean, eager: boolean }} the tag definition
 */
export function getTag(tagIdentifier: number | string): {
    tag: number;
    name: string;
    type: string | number | undefined;
    isArray: boolean;
    eager: boolean;
};
export namespace fieldTypes {
    let BYTE: 1;
    let ASCII: 2;
    let SHORT: 3;
    let LONG: 4;
    let RATIONAL: 5;
    let SBYTE: 6;
    let UNDEFINED: 7;
    let SSHORT: 8;
    let SLONG: 9;
    let SRATIONAL: 10;
    let FLOAT: 11;
    let DOUBLE: 12;
    let IFD: 13;
    let LONG8: 16;
    let SLONG8: 17;
    let IFD8: 18;
}
/** @typedef {keyof fieldTypes} FieldTypeName */
/** @typedef {fieldTypes[keyof typeof fieldTypes]} FieldType */
/** @typedef {Record<FieldTypeName, number>} FieldTypeSizes */
export const fieldTypeSizes: {
    readonly 1: 1;
    readonly 2: 1;
    readonly 6: 1;
    readonly 7: 1;
    readonly 3: 2;
    readonly 8: 2;
    readonly 4: 4;
    readonly 9: 4;
    readonly 11: 4;
    readonly 13: 4;
    readonly 5: 8;
    readonly 10: 8;
    readonly 12: 8;
    readonly 16: 8;
    readonly 17: 8;
    readonly 18: 8;
};
export namespace tagDictionary {
    namespace NewSubfileType {
        export let tag: 254;
        import type = fieldTypes.LONG;
        export { type };
        export let eager: true;
    }
    namespace SubfileType {
        let tag_1: 255;
        export { tag_1 as tag };
        import type_1 = fieldTypes.SHORT;
        export { type_1 as type };
        let eager_1: true;
        export { eager_1 as eager };
    }
    namespace ImageWidth {
        let tag_2: 256;
        export { tag_2 as tag };
        import type_2 = fieldTypes.SHORT;
        export { type_2 as type };
        let eager_2: true;
        export { eager_2 as eager };
    }
    namespace ImageLength {
        let tag_3: 257;
        export { tag_3 as tag };
        import type_3 = fieldTypes.SHORT;
        export { type_3 as type };
        let eager_3: true;
        export { eager_3 as eager };
    }
    namespace BitsPerSample {
        let tag_4: 258;
        export { tag_4 as tag };
        import type_4 = fieldTypes.SHORT;
        export { type_4 as type };
        export let isArray: true;
        let eager_4: true;
        export { eager_4 as eager };
    }
    namespace Compression {
        let tag_5: 259;
        export { tag_5 as tag };
        import type_5 = fieldTypes.SHORT;
        export { type_5 as type };
        let eager_5: true;
        export { eager_5 as eager };
    }
    namespace PhotometricInterpretation {
        let tag_6: 262;
        export { tag_6 as tag };
        import type_6 = fieldTypes.SHORT;
        export { type_6 as type };
        let eager_6: true;
        export { eager_6 as eager };
    }
    namespace Threshholding {
        let tag_7: 263;
        export { tag_7 as tag };
        import type_7 = fieldTypes.SHORT;
        export { type_7 as type };
    }
    namespace CellWidth {
        let tag_8: 264;
        export { tag_8 as tag };
        import type_8 = fieldTypes.SHORT;
        export { type_8 as type };
    }
    namespace CellLength {
        let tag_9: 265;
        export { tag_9 as tag };
        import type_9 = fieldTypes.SHORT;
        export { type_9 as type };
    }
    namespace FillOrder {
        let tag_10: 266;
        export { tag_10 as tag };
        import type_10 = fieldTypes.SHORT;
        export { type_10 as type };
    }
    namespace DocumentName {
        let tag_11: 269;
        export { tag_11 as tag };
        import type_11 = fieldTypes.ASCII;
        export { type_11 as type };
    }
    namespace ImageDescription {
        let tag_12: 270;
        export { tag_12 as tag };
        import type_12 = fieldTypes.ASCII;
        export { type_12 as type };
    }
    namespace Make {
        let tag_13: 271;
        export { tag_13 as tag };
        import type_13 = fieldTypes.ASCII;
        export { type_13 as type };
    }
    namespace Model {
        let tag_14: 272;
        export { tag_14 as tag };
        import type_14 = fieldTypes.ASCII;
        export { type_14 as type };
    }
    namespace StripOffsets {
        let tag_15: 273;
        export { tag_15 as tag };
        import type_15 = fieldTypes.SHORT;
        export { type_15 as type };
        let isArray_1: true;
        export { isArray_1 as isArray };
    }
    namespace Orientation {
        let tag_16: 274;
        export { tag_16 as tag };
        import type_16 = fieldTypes.SHORT;
        export { type_16 as type };
    }
    namespace SamplesPerPixel {
        let tag_17: 277;
        export { tag_17 as tag };
        import type_17 = fieldTypes.SHORT;
        export { type_17 as type };
        let eager_7: true;
        export { eager_7 as eager };
    }
    namespace RowsPerStrip {
        let tag_18: 278;
        export { tag_18 as tag };
        import type_18 = fieldTypes.SHORT;
        export { type_18 as type };
        let eager_8: true;
        export { eager_8 as eager };
    }
    namespace StripByteCounts {
        let tag_19: 279;
        export { tag_19 as tag };
        import type_19 = fieldTypes.LONG;
        export { type_19 as type };
        let isArray_2: true;
        export { isArray_2 as isArray };
    }
    namespace MinSampleValue {
        let tag_20: 280;
        export { tag_20 as tag };
        import type_20 = fieldTypes.SHORT;
        export { type_20 as type };
        let isArray_3: true;
        export { isArray_3 as isArray };
    }
    namespace MaxSampleValue {
        let tag_21: 281;
        export { tag_21 as tag };
        import type_21 = fieldTypes.SHORT;
        export { type_21 as type };
        let isArray_4: true;
        export { isArray_4 as isArray };
    }
    namespace XResolution {
        let tag_22: 282;
        export { tag_22 as tag };
        import type_22 = fieldTypes.RATIONAL;
        export { type_22 as type };
    }
    namespace YResolution {
        let tag_23: 283;
        export { tag_23 as tag };
        import type_23 = fieldTypes.RATIONAL;
        export { type_23 as type };
    }
    namespace PlanarConfiguration {
        let tag_24: 284;
        export { tag_24 as tag };
        import type_24 = fieldTypes.SHORT;
        export { type_24 as type };
        let eager_9: true;
        export { eager_9 as eager };
    }
    namespace PageName {
        let tag_25: 285;
        export { tag_25 as tag };
        import type_25 = fieldTypes.ASCII;
        export { type_25 as type };
    }
    namespace XPosition {
        let tag_26: 286;
        export { tag_26 as tag };
        import type_26 = fieldTypes.RATIONAL;
        export { type_26 as type };
    }
    namespace YPosition {
        let tag_27: 287;
        export { tag_27 as tag };
        import type_27 = fieldTypes.RATIONAL;
        export { type_27 as type };
    }
    namespace FreeOffsets {
        let tag_28: 288;
        export { tag_28 as tag };
        import type_28 = fieldTypes.LONG;
        export { type_28 as type };
    }
    namespace FreeByteCounts {
        let tag_29: 289;
        export { tag_29 as tag };
        import type_29 = fieldTypes.LONG;
        export { type_29 as type };
    }
    namespace GrayResponseUnit {
        let tag_30: 290;
        export { tag_30 as tag };
        import type_30 = fieldTypes.SHORT;
        export { type_30 as type };
    }
    namespace GrayResponseCurve {
        let tag_31: 291;
        export { tag_31 as tag };
        import type_31 = fieldTypes.SHORT;
        export { type_31 as type };
        let isArray_5: true;
        export { isArray_5 as isArray };
    }
    namespace T4Options {
        let tag_32: 292;
        export { tag_32 as tag };
        import type_32 = fieldTypes.LONG;
        export { type_32 as type };
    }
    namespace T6Options {
        let tag_33: 293;
        export { tag_33 as tag };
        import type_33 = fieldTypes.LONG;
        export { type_33 as type };
    }
    namespace ResolutionUnit {
        let tag_34: 296;
        export { tag_34 as tag };
        import type_34 = fieldTypes.SHORT;
        export { type_34 as type };
    }
    namespace PageNumber {
        let tag_35: 297;
        export { tag_35 as tag };
        import type_35 = fieldTypes.SHORT;
        export { type_35 as type };
        let isArray_6: true;
        export { isArray_6 as isArray };
    }
    namespace TransferFunction {
        let tag_36: 301;
        export { tag_36 as tag };
        import type_36 = fieldTypes.SHORT;
        export { type_36 as type };
        let isArray_7: true;
        export { isArray_7 as isArray };
    }
    namespace Software {
        let tag_37: 305;
        export { tag_37 as tag };
        import type_37 = fieldTypes.ASCII;
        export { type_37 as type };
    }
    namespace DateTime {
        let tag_38: 306;
        export { tag_38 as tag };
        import type_38 = fieldTypes.ASCII;
        export { type_38 as type };
    }
    namespace Artist {
        let tag_39: 315;
        export { tag_39 as tag };
        import type_39 = fieldTypes.ASCII;
        export { type_39 as type };
    }
    namespace HostComputer {
        let tag_40: 316;
        export { tag_40 as tag };
        import type_40 = fieldTypes.ASCII;
        export { type_40 as type };
    }
    namespace Predictor {
        let tag_41: 317;
        export { tag_41 as tag };
        import type_41 = fieldTypes.SHORT;
        export { type_41 as type };
    }
    namespace WhitePoint {
        let tag_42: 318;
        export { tag_42 as tag };
        import type_42 = fieldTypes.RATIONAL;
        export { type_42 as type };
        let isArray_8: true;
        export { isArray_8 as isArray };
    }
    namespace PrimaryChromaticities {
        let tag_43: 319;
        export { tag_43 as tag };
        import type_43 = fieldTypes.RATIONAL;
        export { type_43 as type };
        let isArray_9: true;
        export { isArray_9 as isArray };
    }
    namespace ColorMap {
        let tag_44: 320;
        export { tag_44 as tag };
        import type_44 = fieldTypes.SHORT;
        export { type_44 as type };
        let isArray_10: true;
        export { isArray_10 as isArray };
    }
    namespace HalftoneHints {
        let tag_45: 321;
        export { tag_45 as tag };
        import type_45 = fieldTypes.SHORT;
        export { type_45 as type };
        let isArray_11: true;
        export { isArray_11 as isArray };
    }
    namespace TileWidth {
        let tag_46: 322;
        export { tag_46 as tag };
        import type_46 = fieldTypes.SHORT;
        export { type_46 as type };
        let eager_10: true;
        export { eager_10 as eager };
    }
    namespace TileLength {
        let tag_47: 323;
        export { tag_47 as tag };
        import type_47 = fieldTypes.SHORT;
        export { type_47 as type };
        let eager_11: true;
        export { eager_11 as eager };
    }
    namespace TileOffsets {
        let tag_48: 324;
        export { tag_48 as tag };
        import type_48 = fieldTypes.LONG;
        export { type_48 as type };
        let isArray_12: true;
        export { isArray_12 as isArray };
    }
    namespace TileByteCounts {
        let tag_49: 325;
        export { tag_49 as tag };
        import type_49 = fieldTypes.SHORT;
        export { type_49 as type };
        let isArray_13: true;
        export { isArray_13 as isArray };
    }
    namespace InkSet {
        let tag_50: 332;
        export { tag_50 as tag };
        import type_50 = fieldTypes.SHORT;
        export { type_50 as type };
    }
    namespace InkNames {
        let tag_51: 333;
        export { tag_51 as tag };
        import type_51 = fieldTypes.ASCII;
        export { type_51 as type };
    }
    namespace NumberOfInks {
        let tag_52: 334;
        export { tag_52 as tag };
        import type_52 = fieldTypes.SHORT;
        export { type_52 as type };
    }
    namespace DotRange {
        let tag_53: 336;
        export { tag_53 as tag };
        import type_53 = fieldTypes.BYTE;
        export { type_53 as type };
        let isArray_14: true;
        export { isArray_14 as isArray };
    }
    namespace TargetPrinter {
        let tag_54: 337;
        export { tag_54 as tag };
        import type_54 = fieldTypes.ASCII;
        export { type_54 as type };
    }
    namespace ExtraSamples {
        let tag_55: 338;
        export { tag_55 as tag };
        import type_55 = fieldTypes.BYTE;
        export { type_55 as type };
        let isArray_15: true;
        export { isArray_15 as isArray };
        let eager_12: true;
        export { eager_12 as eager };
    }
    namespace SampleFormat {
        let tag_56: 339;
        export { tag_56 as tag };
        import type_56 = fieldTypes.SHORT;
        export { type_56 as type };
        let isArray_16: true;
        export { isArray_16 as isArray };
        let eager_13: true;
        export { eager_13 as eager };
    }
    namespace SMinSampleValue {
        let tag_57: 340;
        export { tag_57 as tag };
        let isArray_17: true;
        export { isArray_17 as isArray };
    }
    namespace SMaxSampleValue {
        let tag_58: 341;
        export { tag_58 as tag };
        let isArray_18: true;
        export { isArray_18 as isArray };
    }
    namespace TransferRange {
        let tag_59: 342;
        export { tag_59 as tag };
        import type_57 = fieldTypes.SHORT;
        export { type_57 as type };
        let isArray_19: true;
        export { isArray_19 as isArray };
    }
    namespace JPEGProc {
        let tag_60: 512;
        export { tag_60 as tag };
        import type_58 = fieldTypes.SHORT;
        export { type_58 as type };
    }
    namespace JPEGInterchangeFormat {
        let tag_61: 513;
        export { tag_61 as tag };
        import type_59 = fieldTypes.LONG;
        export { type_59 as type };
    }
    namespace JPEGInterchangeFormatLngth {
        let tag_62: 514;
        export { tag_62 as tag };
        import type_60 = fieldTypes.LONG;
        export { type_60 as type };
    }
    namespace JPEGRestartInterval {
        let tag_63: 515;
        export { tag_63 as tag };
        import type_61 = fieldTypes.SHORT;
        export { type_61 as type };
    }
    namespace JPEGLosslessPredictors {
        let tag_64: 517;
        export { tag_64 as tag };
        import type_62 = fieldTypes.SHORT;
        export { type_62 as type };
        let isArray_20: true;
        export { isArray_20 as isArray };
    }
    namespace JPEGPointTransforms {
        let tag_65: 518;
        export { tag_65 as tag };
        import type_63 = fieldTypes.SHORT;
        export { type_63 as type };
        let isArray_21: true;
        export { isArray_21 as isArray };
    }
    namespace JPEGQTables {
        let tag_66: 519;
        export { tag_66 as tag };
        import type_64 = fieldTypes.LONG;
        export { type_64 as type };
        let isArray_22: true;
        export { isArray_22 as isArray };
    }
    namespace JPEGDCTables {
        let tag_67: 520;
        export { tag_67 as tag };
        import type_65 = fieldTypes.LONG;
        export { type_65 as type };
        let isArray_23: true;
        export { isArray_23 as isArray };
    }
    namespace JPEGACTables {
        let tag_68: 521;
        export { tag_68 as tag };
        import type_66 = fieldTypes.LONG;
        export { type_66 as type };
        let isArray_24: true;
        export { isArray_24 as isArray };
    }
    namespace YCbCrCoefficients {
        let tag_69: 529;
        export { tag_69 as tag };
        import type_67 = fieldTypes.RATIONAL;
        export { type_67 as type };
        let isArray_25: true;
        export { isArray_25 as isArray };
    }
    namespace YCbCrSubSampling {
        let tag_70: 530;
        export { tag_70 as tag };
        import type_68 = fieldTypes.SHORT;
        export { type_68 as type };
        let isArray_26: true;
        export { isArray_26 as isArray };
    }
    namespace YCbCrPositioning {
        let tag_71: 531;
        export { tag_71 as tag };
        import type_69 = fieldTypes.SHORT;
        export { type_69 as type };
    }
    namespace ReferenceBlackWhite {
        let tag_72: 532;
        export { tag_72 as tag };
        import type_70 = fieldTypes.LONG;
        export { type_70 as type };
        let isArray_27: true;
        export { isArray_27 as isArray };
    }
    namespace Copyright {
        let tag_73: 33432;
        export { tag_73 as tag };
        import type_71 = fieldTypes.ASCII;
        export { type_71 as type };
    }
    namespace BadFaxLines {
        let tag_74: 326;
        export { tag_74 as tag };
    }
    namespace CleanFaxData {
        let tag_75: 327;
        export { tag_75 as tag };
    }
    namespace ClipPath {
        let tag_76: 343;
        export { tag_76 as tag };
    }
    namespace ConsecutiveBadFaxLines {
        let tag_77: 328;
        export { tag_77 as tag };
    }
    namespace Decode {
        let tag_78: 433;
        export { tag_78 as tag };
    }
    namespace DefaultImageColor {
        let tag_79: 434;
        export { tag_79 as tag };
    }
    namespace Indexed {
        let tag_80: 346;
        export { tag_80 as tag };
    }
    namespace JPEGTables {
        let tag_81: 347;
        export { tag_81 as tag };
        let isArray_28: true;
        export { isArray_28 as isArray };
        let eager_14: true;
        export { eager_14 as eager };
    }
    namespace StripRowCounts {
        let tag_82: 559;
        export { tag_82 as tag };
        let isArray_29: true;
        export { isArray_29 as isArray };
    }
    namespace SubIFDs {
        let tag_83: 330;
        export { tag_83 as tag };
        let isArray_30: true;
        export { isArray_30 as isArray };
    }
    namespace XClipPathUnits {
        let tag_84: 344;
        export { tag_84 as tag };
    }
    namespace YClipPathUnits {
        let tag_85: 345;
        export { tag_85 as tag };
    }
    namespace ApertureValue {
        let tag_86: 37378;
        export { tag_86 as tag };
    }
    namespace ColorSpace {
        let tag_87: 40961;
        export { tag_87 as tag };
    }
    namespace DateTimeDigitized {
        let tag_88: 36868;
        export { tag_88 as tag };
    }
    namespace DateTimeOriginal {
        let tag_89: 36867;
        export { tag_89 as tag };
    }
    namespace ExifIFD {
        let tag_90: 34665;
        export { tag_90 as tag };
        export let name: "Exif IFD";
        import type_72 = fieldTypes.LONG;
        export { type_72 as type };
    }
    namespace ExifVersion {
        let tag_91: 36864;
        export { tag_91 as tag };
    }
    namespace ExposureTime {
        let tag_92: 33434;
        export { tag_92 as tag };
    }
    namespace FileSource {
        let tag_93: 41728;
        export { tag_93 as tag };
    }
    namespace Flash {
        let tag_94: 37385;
        export { tag_94 as tag };
    }
    namespace FlashpixVersion {
        let tag_95: 40960;
        export { tag_95 as tag };
    }
    namespace FNumber {
        let tag_96: 33437;
        export { tag_96 as tag };
    }
    namespace ImageUniqueID {
        let tag_97: 42016;
        export { tag_97 as tag };
    }
    namespace LightSource {
        let tag_98: 37384;
        export { tag_98 as tag };
    }
    namespace MakerNote {
        let tag_99: 37500;
        export { tag_99 as tag };
    }
    namespace ShutterSpeedValue {
        let tag_100: 37377;
        export { tag_100 as tag };
    }
    namespace UserComment {
        let tag_101: 37510;
        export { tag_101 as tag };
    }
    namespace IPTC {
        let tag_102: 33723;
        export { tag_102 as tag };
    }
    namespace CZ_LSMINFO {
        let tag_103: 34412;
        export { tag_103 as tag };
    }
    namespace ICCProfile {
        let tag_104: 34675;
        export { tag_104 as tag };
        let name_1: "ICC Profile";
        export { name_1 as name };
    }
    namespace XMP {
        let tag_105: 700;
        export { tag_105 as tag };
    }
    namespace GDAL_METADATA {
        let tag_106: 42112;
        export { tag_106 as tag };
    }
    namespace GDAL_NODATA {
        let tag_107: 42113;
        export { tag_107 as tag };
        import type_73 = fieldTypes.ASCII;
        export { type_73 as type };
        let eager_15: true;
        export { eager_15 as eager };
    }
    namespace Photoshop {
        let tag_108: 34377;
        export { tag_108 as tag };
    }
    namespace ModelPixelScale {
        let tag_109: 33550;
        export { tag_109 as tag };
        import type_74 = fieldTypes.DOUBLE;
        export { type_74 as type };
        let isArray_31: true;
        export { isArray_31 as isArray };
        let eager_16: true;
        export { eager_16 as eager };
    }
    namespace ModelTiepoint {
        let tag_110: 33922;
        export { tag_110 as tag };
        import type_75 = fieldTypes.DOUBLE;
        export { type_75 as type };
        let isArray_32: true;
        export { isArray_32 as isArray };
        let eager_17: true;
        export { eager_17 as eager };
    }
    namespace ModelTransformation {
        let tag_111: 34264;
        export { tag_111 as tag };
        import type_76 = fieldTypes.DOUBLE;
        export { type_76 as type };
        let isArray_33: true;
        export { isArray_33 as isArray };
        let eager_18: true;
        export { eager_18 as eager };
    }
    namespace GeoKeyDirectory {
        let tag_112: 34735;
        export { tag_112 as tag };
        import type_77 = fieldTypes.SHORT;
        export { type_77 as type };
        let isArray_34: true;
        export { isArray_34 as isArray };
        let eager_19: true;
        export { eager_19 as eager };
    }
    namespace GeoDoubleParams {
        let tag_113: 34736;
        export { tag_113 as tag };
        import type_78 = fieldTypes.DOUBLE;
        export { type_78 as type };
        let isArray_35: true;
        export { isArray_35 as isArray };
        let eager_20: true;
        export { eager_20 as eager };
    }
    namespace GeoAsciiParams {
        let tag_114: 34737;
        export { tag_114 as tag };
        import type_79 = fieldTypes.ASCII;
        export { type_79 as type };
        let eager_21: true;
        export { eager_21 as eager };
    }
    namespace LercParameters {
        let tag_115: 50674;
        export { tag_115 as tag };
        let eager_22: true;
        export { eager_22 as eager };
    }
}
/** @typedef {keyof typeof tagDictionary} TagName */
/** @typedef {typeof tagDictionary[keyof typeof tagDictionary]['tag']} Tag */
/**
 * @typedef {Extract<keyof typeof tagDictionary,
 *   { [K in keyof typeof tagDictionary]: (typeof tagDictionary)[K] extends { eager: true }
 *   ? K : never }[keyof typeof tagDictionary]>} EagerTagName
 */
/**
 * @typedef {Extract<Tag, { [K in keyof typeof tagDictionary]: (typeof tagDictionary)[K] extends { eager: true }
 *   ? (typeof tagDictionary)[K]['tag'] : never }[keyof typeof tagDictionary]>} EagerTag
 */
/** @typedef {Extract<typeof tagDictionary[keyof typeof tagDictionary], {type: any}>['type']} TagType */
/**
 * @template {number} T
 * @typedef {T extends 2 ? string : number} GeoTiffPrimitive
 */
/**
 * @template {TagName} T
 * @typedef {typeof tagDictionary[T]} TagDef
 */
/**
 * @typedef {{
 *   1: number;
 *   2: string;
 *   3: number;
 *   4: number;
 *   5: number;
 *   6: number;
 *   7: ArrayBuffer;
 *   8: number;
 *   9: number;
 *   10: number;
 *   11: number;
 *   12: number;
 *   16: number;
 *   17: number;
 *   18: number;
 * }} FieldTypeMap
 */
/**
 * @template {TagName} T
 * @typedef {TagDef<T> extends { isArray: true }
 *   ? (TagDef<T> extends { type: typeof fieldTypes.DOUBLE } ? number[] :
 *      TagDef<T> extends { type: typeof fieldTypes.ASCII } ? string[] :
 *      TagDef<T> extends { type: typeof fieldTypes.BYTE | typeof fieldTypes.SBYTE | typeof fieldTypes.UNDEFINED }
 *        ? Uint8Array | Int8Array :
 *      (number[] | TypedArray))
 *   : (TagDef<T> extends { type: keyof FieldTypeMap } ? FieldTypeMap[TagDef<T>['type']] : any)} TagValue
 */
/**
 * Maps tag names to their numeric values
 * @type {Record<string, number>}
 */
export const tags: Record<string, number>;
/**
 * Maps tag numbers to their definitions
 * @type {Record<number, { tag: number, name: string, type: string|number|undefined, isArray: boolean, eager: boolean }>}
 */
export const tagDefinitions: Record<number, {
    tag: number;
    name: string;
    type: string | number | undefined;
    isArray: boolean;
    eager: boolean;
}>;
export const fieldTagTypes: {
    256: string;
    257: string;
    258: string;
    259: string;
    262: string;
    270: string;
    271: string;
    272: string;
    273: string;
    274: string;
    277: string;
    278: string;
    279: string;
    282: string;
    283: string;
    284: string;
    286: string;
    287: string;
    296: string;
    297: string;
    305: string;
    306: string;
    315: string;
    338: string;
    339: string;
    513: string;
    514: string;
    1024: string;
    1025: string;
    1026: string;
    2048: string;
    2049: string;
    2052: string;
    2054: string;
    2057: string;
    2059: string;
    2060: string;
    3072: string;
    3073: string;
    3076: string;
    4096: string;
    4097: string;
    4099: string;
    33432: string;
    33550: string;
    33922: string;
    34264: string;
    34665: string;
    34735: string;
    34736: string;
    34737: string;
    42113: string;
};
export namespace photometricInterpretations {
    let WhiteIsZero: number;
    let BlackIsZero: number;
    let RGB: number;
    let Palette: number;
    let TransparencyMask: number;
    let CMYK: number;
    let YCbCr: number;
    let CIELab: number;
    let ICCLab: number;
}
export namespace ExtraSamplesValues {
    let Unspecified: number;
    let Assocalpha: number;
    let Unassalpha: number;
}
export namespace LercParameters {
    let Version: number;
    let AddCompression: number;
}
export namespace LercAddCompression {
    let None: number;
    let Deflate: number;
    let Zstandard: number;
}
export const geoKeyNames: {
    readonly 1024: "GTModelTypeGeoKey";
    readonly 1025: "GTRasterTypeGeoKey";
    readonly 1026: "GTCitationGeoKey";
    readonly 2048: "GeographicTypeGeoKey";
    readonly 2049: "GeogCitationGeoKey";
    readonly 2050: "GeogGeodeticDatumGeoKey";
    readonly 2051: "GeogPrimeMeridianGeoKey";
    readonly 2052: "GeogLinearUnitsGeoKey";
    readonly 2053: "GeogLinearUnitSizeGeoKey";
    readonly 2054: "GeogAngularUnitsGeoKey";
    readonly 2055: "GeogAngularUnitSizeGeoKey";
    readonly 2056: "GeogEllipsoidGeoKey";
    readonly 2057: "GeogSemiMajorAxisGeoKey";
    readonly 2058: "GeogSemiMinorAxisGeoKey";
    readonly 2059: "GeogInvFlatteningGeoKey";
    readonly 2060: "GeogAzimuthUnitsGeoKey";
    readonly 2061: "GeogPrimeMeridianLongGeoKey";
    readonly 2062: "GeogTOWGS84GeoKey";
    readonly 3072: "ProjectedCSTypeGeoKey";
    readonly 3073: "PCSCitationGeoKey";
    readonly 3074: "ProjectionGeoKey";
    readonly 3075: "ProjCoordTransGeoKey";
    readonly 3076: "ProjLinearUnitsGeoKey";
    readonly 3077: "ProjLinearUnitSizeGeoKey";
    readonly 3078: "ProjStdParallel1GeoKey";
    readonly 3079: "ProjStdParallel2GeoKey";
    readonly 3080: "ProjNatOriginLongGeoKey";
    readonly 3081: "ProjNatOriginLatGeoKey";
    readonly 3082: "ProjFalseEastingGeoKey";
    readonly 3083: "ProjFalseNorthingGeoKey";
    readonly 3084: "ProjFalseOriginLongGeoKey";
    readonly 3085: "ProjFalseOriginLatGeoKey";
    readonly 3086: "ProjFalseOriginEastingGeoKey";
    readonly 3087: "ProjFalseOriginNorthingGeoKey";
    readonly 3088: "ProjCenterLongGeoKey";
    readonly 3089: "ProjCenterLatGeoKey";
    readonly 3090: "ProjCenterEastingGeoKey";
    readonly 3091: "ProjCenterNorthingGeoKey";
    readonly 3092: "ProjScaleAtNatOriginGeoKey";
    readonly 3093: "ProjScaleAtCenterGeoKey";
    readonly 3094: "ProjAzimuthAngleGeoKey";
    readonly 3095: "ProjStraightVertPoleLongGeoKey";
    readonly 3096: "ProjRectifiedGridAngleGeoKey";
    readonly 4096: "VerticalCSTypeGeoKey";
    readonly 4097: "VerticalCitationGeoKey";
    readonly 4098: "VerticalDatumGeoKey";
    readonly 4099: "VerticalUnitsGeoKey";
};
/** @typedef {geoKeyNames[keyof typeof geoKeyNames]} GeoKeyName */
/**
 * @type {Record<GeoKeyName, number>}
 */
export const geoKeys: Record<GeoKeyName, number>;
export type FieldTypeSize = 4 | 2 | 8 | 1;
export type FieldTypeName = "BYTE" | "ASCII" | "SHORT" | "LONG" | "RATIONAL" | "SBYTE" | "UNDEFINED" | "SSHORT" | "SLONG" | "SRATIONAL" | "FLOAT" | "DOUBLE" | "IFD" | "LONG8" | "SLONG8" | "IFD8";
export type FieldType = 4 | 2 | 7 | 8 | 1 | 3 | 5 | 6 | 9 | 10 | 11 | 12 | 13 | 16 | 17 | 18;
export type FieldTypeSizes = Record<FieldTypeName, number>;
export type TagDictionaryEntry = {
    tag: number;
    name?: string | undefined;
    type?: number | undefined;
    isArray?: boolean | undefined;
    eager?: boolean | undefined;
};
export type TagName = keyof typeof tagDictionary;
export type Tag = (typeof tagDictionary)[keyof typeof tagDictionary]["tag"];
export type EagerTagName = Extract<keyof typeof tagDictionary, { [K in keyof typeof tagDictionary]: (typeof tagDictionary)[K] extends {
    eager: true;
} ? K : never; }[keyof typeof tagDictionary]>;
export type EagerTag = Extract<Tag, { [K in keyof typeof tagDictionary]: (typeof tagDictionary)[K] extends {
    eager: true;
} ? (typeof tagDictionary)[K]["tag"] : never; }[keyof typeof tagDictionary]>;
export type TagType = Extract<(typeof tagDictionary)[keyof typeof tagDictionary], {
    type: any;
}>["type"];
export type GeoTiffPrimitive<T extends number> = T extends 2 ? string : number;
export type TagDef<T extends TagName> = (typeof tagDictionary)[T];
export type FieldTypeMap = {
    1: number;
    2: string;
    3: number;
    4: number;
    5: number;
    6: number;
    7: ArrayBuffer;
    8: number;
    9: number;
    10: number;
    11: number;
    12: number;
    16: number;
    17: number;
    18: number;
};
export type TagValue<T extends TagName> = TagDef<T> extends {
    isArray: true;
} ? (TagDef<T> extends {
    type: typeof fieldTypes.DOUBLE;
} ? number[] : TagDef<T> extends {
    type: typeof fieldTypes.ASCII;
} ? string[] : TagDef<T> extends {
    type: typeof fieldTypes.BYTE | typeof fieldTypes.SBYTE | typeof fieldTypes.UNDEFINED;
} ? Uint8Array | Int8Array : (number[] | TypedArray)) : (TagDef<T> extends {
    type: keyof FieldTypeMap;
} ? FieldTypeMap[TagDef<T>["type"]] : any);
export type GeoKeyName = "GTModelTypeGeoKey" | "GTRasterTypeGeoKey" | "GTCitationGeoKey" | "GeographicTypeGeoKey" | "GeogCitationGeoKey" | "GeogGeodeticDatumGeoKey" | "GeogPrimeMeridianGeoKey" | "GeogLinearUnitsGeoKey" | "GeogLinearUnitSizeGeoKey" | "GeogAngularUnitsGeoKey" | "GeogAngularUnitSizeGeoKey" | "GeogEllipsoidGeoKey" | "GeogSemiMajorAxisGeoKey" | "GeogSemiMinorAxisGeoKey" | "GeogInvFlatteningGeoKey" | "GeogAzimuthUnitsGeoKey" | "GeogPrimeMeridianLongGeoKey" | "GeogTOWGS84GeoKey" | "ProjectedCSTypeGeoKey" | "PCSCitationGeoKey" | "ProjectionGeoKey" | "ProjCoordTransGeoKey" | "ProjLinearUnitsGeoKey" | "ProjLinearUnitSizeGeoKey" | "ProjStdParallel1GeoKey" | "ProjStdParallel2GeoKey" | "ProjNatOriginLongGeoKey" | "ProjNatOriginLatGeoKey" | "ProjFalseEastingGeoKey" | "ProjFalseNorthingGeoKey" | "ProjFalseOriginLongGeoKey" | "ProjFalseOriginLatGeoKey" | "ProjFalseOriginEastingGeoKey" | "ProjFalseOriginNorthingGeoKey" | "ProjCenterLongGeoKey" | "ProjCenterLatGeoKey" | "ProjCenterEastingGeoKey" | "ProjCenterNorthingGeoKey" | "ProjScaleAtNatOriginGeoKey" | "ProjScaleAtCenterGeoKey" | "ProjAzimuthAngleGeoKey" | "ProjStraightVertPoleLongGeoKey" | "ProjRectifiedGridAngleGeoKey" | "VerticalCSTypeGeoKey" | "VerticalCitationGeoKey" | "VerticalDatumGeoKey" | "VerticalUnitsGeoKey";
import type { TypedArray } from './geotiff.js';
//# sourceMappingURL=globals.d.ts.map