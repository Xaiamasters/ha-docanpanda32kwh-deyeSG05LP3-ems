export const zstd: any;
export default class ZstdDecoder extends BaseDecoder {
    /** @param {ArrayBuffer} buffer */
    decodeBlock(buffer: ArrayBuffer): ArrayBuffer;
}
import BaseDecoder from './basedecoder.js';
//# sourceMappingURL=zstd.d.ts.map