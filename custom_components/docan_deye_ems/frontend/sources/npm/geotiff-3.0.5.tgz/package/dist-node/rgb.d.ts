export function fromWhiteIsZero(raster: any, max: any): Uint8Array<ArrayBuffer>;
export function fromBlackIsZero(raster: any, max: any): Uint8Array<ArrayBuffer>;
export function fromPalette(raster: any, colorMap: any): Uint8Array<ArrayBuffer>;
export function fromCMYK(cmykRaster: any): Uint8Array<ArrayBuffer>;
export function fromYCbCr(yCbCrRaster: any): Uint8ClampedArray<ArrayBuffer>;
export function fromCIELab(cieLabRaster: any): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=rgb.d.ts.map