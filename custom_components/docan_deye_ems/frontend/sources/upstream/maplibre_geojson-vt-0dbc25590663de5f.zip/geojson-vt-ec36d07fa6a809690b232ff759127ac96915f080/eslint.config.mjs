import eslint from '@eslint/js';
import { defineConfig } from 'eslint/config';
import tseslint from 'typescript-eslint';

export default defineConfig(
    {
        ignores: ['dist/**', '**/*.js']
    },
    eslint.configs.recommended,
    tseslint.configs.recommended
);