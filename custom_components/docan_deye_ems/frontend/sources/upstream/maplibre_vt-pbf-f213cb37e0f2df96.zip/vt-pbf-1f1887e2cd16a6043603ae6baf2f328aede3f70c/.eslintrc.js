module.exports = {
  extends: 'standard'
}
