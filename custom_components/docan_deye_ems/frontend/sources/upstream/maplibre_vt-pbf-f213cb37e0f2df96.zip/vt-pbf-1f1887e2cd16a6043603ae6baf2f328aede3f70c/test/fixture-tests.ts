import {test, expect, describe} from 'vitest';
import geojsonvt from '@maplibre/geojson-vt';
import {VectorTile} from '@mapbox/vector-tile';
import Pbf from 'pbf';
import {isValid} from '@maplibre/vtvalidate';
import geojsonFixtures, {Geometries} from '@mapbox/geojson-fixtures';
import mvtf, {Fixture} from '@mapbox/mvt-fixtures';
import GeoJsonEquality from 'geojson-equality';
import {readFileSync} from 'fs';
import {fromVectorTileJs, fromGeojsonVt} from '../index';

interface FixtureEntry {
  name: string,
  data: GeoJSON.GeoJSON;
};

const eq = new GeoJsonEquality({ precision: 1 });

describe('geojson-vt', function () {
  [
    // Geometries
    ...[
      'polygon',
      'point',
      'multipoint',
      'multipolygon',
      'polygon',
      'multilinestring'
    ].map((type: string): FixtureEntry => {
      return {
        name: type,
        data: {
          type: 'Feature',
          properties: {},
          geometry: geojsonFixtures.geometry[type as Geometries]
        }
      };
    }),
    // FeatureCollection
   {
    name: 'collection',
    data: JSON.parse(
      readFileSync(__dirname + '/fixtures/featurecollection.geojson').toString()
    ) as GeoJSON.GeoJSON
   }
  ].forEach((fixture: FixtureEntry) => {
    test(fixture.name, () => {
      const tile = geojsonvt(fixture.data, {}).getTile(0, 0, 0);
      expect(tile).toBeTruthy();
      if (!tile) {
        return;
      }

      const buff = fromGeojsonVt({ geojsonLayer: tile });
      isValid(buff, (error: Error, result: string) => {
        expect(error).toBeFalsy();
        expect(result).toEqual('');

        // Compare roundtripped features with originals
        const expected = fixture.data.type === 'FeatureCollection' ? fixture.data.features : [fixture.data];
        const layer = new VectorTile(new Pbf(buff)).layers.geojsonLayer;
        expect(layer.length).toEqual(expected.length);
        
        for (let i = 0; i < layer.length; i++) {
          const actual = layer.feature(i).toGeoJSON(0, 0, 0);
          expect(eq.compare(actual, expected[i])).toBeTruthy();
        }
      });
    });
  });
});

describe('vector-tile-js', () => {
  // See https://github.com/mapbox/mvt-fixtures/blob/master/FIXTURES.md for
  // fixture descriptions
  mvtf.each((fixture: Fixture) => {
    // skip invalid tiles
    if (!fixture.validity.v2) return;

    test('mvt-fixtures: ' + fixture.id + ' ' + fixture.description, () => {
      const original = new VectorTile(new Pbf(new Uint8Array(fixture.buffer)));

      if (fixture.id === '020') {
        console.log('Skipping test due to https://github.com/mapbox/vt-pbf/issues/30');
        return;
      }

      if (fixture.id === '049' || fixture.id === '050') {
        console.log('Skipping test due to https://github.com/mapbox/vt-pbf/issues/31');
        return;
      }

      const buff = fromVectorTileJs(original);
      const roundtripped = new VectorTile(new Pbf(buff));

      isValid(buff, (error: Error, message: string) => {
        if (error) {
          throw error;
        }

        // UNKOWN geometry type is valid in the spec, but vtvalidate considers
        // it an error
        if (fixture.id === '016' || fixture.id === '039') {
          message = '';
        }

        expect(!message).toBeTruthy();

        // Compare roundtripped features with originals
        for (const name in original.layers) {
          const originalLayer = original.layers[name];
          expect(roundtripped.layers[name]).toBeTruthy();
          const roundtrippedLayer = roundtripped.layers[name];
          expect(roundtrippedLayer.length).toEqual(originalLayer.length);
          for (let i = 0; i < originalLayer.length; i++) {
            const actual = roundtrippedLayer.feature(i);
            const expected = originalLayer.feature(i);

            expect(actual.id).toEqual(expected.id);
            expect(actual.type).toEqual(expected.type);
            expect(actual.properties).toEqual(expected.properties);
            expect(actual.loadGeometry()).toEqual(expected.loadGeometry());
          }
        }
      });
    });
  });
});
