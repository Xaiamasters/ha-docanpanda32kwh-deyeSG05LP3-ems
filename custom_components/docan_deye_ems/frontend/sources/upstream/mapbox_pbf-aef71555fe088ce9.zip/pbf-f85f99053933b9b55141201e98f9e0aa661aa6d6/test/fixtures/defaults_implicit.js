
export const MessageType = {
    "UNKNOWN": 0,
    "GREETING": 1
};

export function readCustomType(pbf, end) {
    pbf.pos = end;
    return {};
}
export function writeCustomType(obj, pbf) {}

export function readEnvelope(pbf, end) {
    const obj = {type: 0, name: "", flag: false, weight: 0, id: 0, tags: [], numbers: [], bytes: undefined, custom: undefined, types: []};
    let field;
    while ((field = pbf.nextField(end))) {
        if (field === 1) obj.type = pbf.readVarint();
        else if (field === 2) obj.name = pbf.readString();
        else if (field === 3) obj.flag = pbf.readBoolean();
        else if (field === 4) obj.weight = pbf.readFloat();
        else if (field === 5) obj.id = pbf.readVarint(true);
        else if (field === 6) obj.tags.push(pbf.readString());
        else if (field === 7) pbf.readPackedVarint(obj.numbers, true);
        else if (field === 8) obj.bytes = pbf.readBytes();
        else if (field === 9) obj.custom = readCustomType(pbf, pbf.readVarint() + pbf.pos);
        else if (field === 10) pbf.readPackedVarint(obj.types);
    }
    return obj;
}
export function writeEnvelope(obj, pbf) {
    if (obj.type) pbf.writeVarintField(1, obj.type);
    if (obj.name) pbf.writeStringField(2, obj.name);
    if (obj.flag) pbf.writeBooleanField(3, obj.flag);
    if (obj.weight) pbf.writeFloatField(4, obj.weight);
    if (obj.id) pbf.writeVarintField(5, obj.id);
    if (obj.tags) for (const item of obj.tags) pbf.writeStringField(6, item);
    if (obj.numbers) for (const item of obj.numbers) pbf.writeVarintField(7, item);
    if (obj.bytes != null) pbf.writeBytesField(8, obj.bytes);
    if (obj.custom) pbf.writeMessage(9, writeCustomType, obj.custom);
    if (obj.types) for (const item of obj.types) pbf.writeVarintField(10, item);
}
