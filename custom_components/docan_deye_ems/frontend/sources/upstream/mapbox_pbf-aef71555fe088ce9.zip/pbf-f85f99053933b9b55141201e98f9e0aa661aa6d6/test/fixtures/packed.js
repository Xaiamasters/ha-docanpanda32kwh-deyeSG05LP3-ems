
export function readNotPacked(pbf, end) {
    const obj = {value: [], types: []};
    let field;
    while ((field = pbf.nextField(end))) {
        if (field === 1) pbf.readPackedVarint(obj.value, true);
        else if (field === 2) pbf.readPackedVarint(obj.types, true);
    }
    return obj;
}
export function writeNotPacked(obj, pbf) {
    if (obj.value) for (const item of obj.value) pbf.writeVarintField(1, item);
    if (obj.types) for (const item of obj.types) pbf.writeVarintField(2, item);
}

export function readFalsePacked(pbf, end) {
    const obj = {value: [], types: []};
    let field;
    while ((field = pbf.nextField(end))) {
        if (field === 1) pbf.readPackedVarint(obj.value, true);
        else if (field === 2) pbf.readPackedVarint(obj.types, true);
    }
    return obj;
}
export function writeFalsePacked(obj, pbf) {
    if (obj.value) for (const item of obj.value) pbf.writeVarintField(1, item);
    if (obj.types) for (const item of obj.types) pbf.writeVarintField(2, item);
}

export function readPacked(pbf, end) {
    const obj = {value: [], types: []};
    let field;
    while ((field = pbf.nextField(end))) {
        if (field === 1) pbf.readPackedVarint(obj.value, true);
        else if (field === 2) pbf.readPackedVarint(obj.types, true);
    }
    return obj;
}
export function writePacked(obj, pbf) {
    if (obj.value) pbf.writePackedVarint(1, obj.value);
    if (obj.types) pbf.writePackedVarint(2, obj.types);
}
