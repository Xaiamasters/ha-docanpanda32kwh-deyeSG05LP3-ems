import { InverterSettingsDto } from '../dto/inverter-settings.dto';
import { InverterModel } from '../../types';
import { localize } from '../../localize/localize';

export class Sigenergy extends InverterSettingsDto {
	brand = InverterModel.Sigenergy;
	statusGroups = {
		standby: {
			states: ['standby'],
			color: 'blue',
			message: localize('common.standby'),
		},
		running: {
			states: ['running'],
			color: 'green',
			message: localize('common.running'),
		},
		shutdown: {
			states: ['shutdown'],
			color: 'red',
			message: localize('common.shutdown'),
		},
		alarm: {
			states: [
				'software version mismatch',
				'low insulation resistance',
				'over-temperature',
				'equipment fault',
				'system grounding fault',
				'pv string over-voltage',
				'pv string reversely connected',
				'pv string back-filling',
				'afci fault',
				'grid power outage',
				'grid over-voltage',
				'grid under-voltage',
				'grid over-frequency',
				'grid under-frequency',
				'grid voltage imbalance',
				'dc component of output current out of limit',
				'leak current out of limit',
				'system internal protection',
				'afci self-checking circuit fault',
				'off-grid protection',
				'manual operation protection',
				'abnormal phase sequence',
				'short circuit to pe',
				'soft start failure',
				'off-grid protection',
				'manual operation protection',
				'soft start failure',
				'excessive leakage current in off-grid output',
				'n line grounding fault',
				'abnormal phase sequence of grid wiring',
				'abnormal phase sequence of inverter wiring',
				'grid phase loss',
				'the energy storage module has low insulation resistance to ground',
				'the temperature is too high',
				'under-temperature',
				'internal protection',
				'thermal runaway',
			],
			color: 'red',
			message: localize('common.alarm'),
		},
		fault: {
			states: ['fault', 'communication abnormal', 'environmental abnormality'],
			color: 'orange',
			message: localize('common.fault'),
		},
		ongrid: {
			states: ['on grid'],
			color: 'green',
			message: localize('common.ongrid'),
		},
		offgrid: {
			states: ['off grid (auto)', 'off grid (manual)'],
			color: 'yellow',
			message: localize('common.offgrid'),
		},
		externalcontrol: {
			states: [
				'pcs remote control',
				'standby',
				'maximum self consumption',
				'command charging (grid first)',
				'command charging (pv first)',
				'command discharging (pv first)',
				'command discharging (ess first)',
				'unknown',
			],
			color: 'green',
			message: localize('common.externalcontrol'),
		},
	};
	image =
		'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADUAAABICAYAAABWWr1vAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAACw8AAAsPAZL5A6UAAAUgaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8P3hwYWNrZXQgYmVnaW49Iu+7vyIgaWQ9Ilc1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCI/PiA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJBZG9iZSBYTVAgQ29yZSA1LjYtYzE0NSA3OS4xNjM0OTksIDIwMTgvMDgvMTMtMTY6NDA6MjIgICAgICAgICI+IDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+IDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE5IChNYWNpbnRvc2gpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMy0xMi0xOVQxMTozMzowOSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjMtMTItMTlUMTQ6NDY6NDgrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjMtMTItMTlUMTQ6NDY6NDgrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6MjVlYTI1MGYtZTcxMC00NDZjLTkzZTQtMDU1MDQ2MmRkYjhjIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjI1ZWEyNTBmLWU3MTAtNDQ2Yy05M2U0LTA1NTA0NjJkZGI4YyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjI1ZWEyNTBmLWU3MTAtNDQ2Yy05M2U0LTA1NTA0NjJkZGI4YyI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MjVlYTI1MGYtZTcxMC00NDZjLTkzZTQtMDU1MDQ2MmRkYjhjIiBzdEV2dDp3aGVuPSIyMDIzLTEyLTE5VDExOjMzOjA5KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoTWFjaW50b3NoKSIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5AdC25AAAMGklEQVRoQ9VbTYxcRxGueTOzXv+ucdZxFCsoySFCiCQI7EMUuDhAApeIIMSJq8URLohTJFDEgQPkBBw4cLHECXHhQEKIQFiyDwjJAqGQRA7I/xt7/2zvzszODPVVd/Wr6tdvZpJISPmcnq6fr6qrX7/Xr3d2Q4o333yzd/fu3W/v7u6+NhqNBtOPGcaMy5cvv4G5dPBx/vz5B0+fPv2Hfr//WejTyTR6Ph7QequqogsXLpyT0i9evPi7p5566kXIo+GIxntj6na7oHMzs4siOngA9WbMVrTxNJ9DMtZeZ+JEvEhc7x5VXC8vFu0Odqn7+uuvP37o0KGf3793nw7uP0CTyUSInY6WXidUsDuh6V0cGtvIAYMYk5CQtOia8DLxZCa9brcac+3b29tUcfFf7vf6dGD/flk+mX66lBCikmyMSDHeiNxidc8ErMd5k0GF2pskYw5dVPiKV4PB4BneHGjf8rKsUHCEzqFga5pgsVaVMWAhwTzEOmehptRjVbzTPcETo16v524rlxByYYD2MW0Aki42ocYwjbD2EdXHtyNVw8FwdTQa4j7kHDMGX6wuBpIvPhELjepxLQf5UViq7CQ0bz41efj5uWEf/1d1KuKHa7y0x7sdfImchJBEYDJBNJ4MuccELoClboe2h3v0t/tDurI7oj6XK2XHvPj0I8j9NRExDlXhxRVEg2RhVqEmuNtLhUe96HN2eyQmdH1jRL+4MaLvXXqXfnVrky5tDKibcpgL34COxRuF6CXoxAJPWntCCw0A0OdR6vOo+FbbHUzo0n+m9Jcf/4Te/un36Y2Xf0D/eu86vb8zoT5PuC02QMfijUJ0C63B1hJlDevy/Y73GFpVdakjerBJ0qiHPrzpaz+gfY1OxS/RwSG69Me/0t//9Gvav3aL3jr/Gv35t7+hvel+wjtI45rRQLBOsVGEyfOHXgTtc8RMEz6S3L+/Q3gOB4MhbWxs0IBfCdhB8UZHgp2doAfeHm1tbdG9e/dEnqS73Zc27Uxpst2ld9/+B3VOrlDnvdt0YPUYvfXeO3TlnTs8KRwIIpdbc2Ihr1zMpFoWZDFqAQHYWYZDfoCvXKW1tTW6feeOvMGhb2xu0Pvv36brN27StWvXaGt7i24x59atNdrc3KSd3R2+AJuFYgJ4MWk8JFrePEyTdeY9cJjG13kyV9doff0q9fvhyVKo7CsMCLdf9DQJXIKpAku7tNSn48dX6ejRFVret4/280nkwRMPEh+16NgDx2jlyBFaXV2lw6yfYPvKygp1+R0I+7Fjn5BbMYzkR5tOKuod2aVnP/8inXjsc7S+fYe5PXr2i1+gkw8v81m0jwIaNeYXCfte96VvvPTdgwcOHj358Em+r5nCUXBU3fi4IQqZYjTeZwcOHuAr16fl5TCpZW5LrKPgfTLRZep1e8xBW6JDzMezh82gtNkC00mHlo/wuZNXZG9tH60crejr3/wWfe2FL9GnnngscDg2nwQmyufVKR/AK5xbcTrqnDt37vLx1eOP8o8esgHgmcFbWU7pOn6WKZvnDCgTsHIT8OCCUWdM/37rOm1sbdJDDx3jVTrBFyicwC0005QL5md1whevO9ob8SNxu2VLR0TL+PMnAigLSeZH6FDYRKbTij7z5GP07DNP0+OPPiKrHyaEPPNzyYkiiJw2TSIKLfFKm50+JTMo2QJsubg7d3eHNOCf64bc5AdA8aIPOWymIKs/IG7pjFQlC57joLQWt8HizFakmnyOZGawDNXccfFEISE2Lsks2AwMdWVmRtNS20o+D5s3sVMdzloj+PmTN4Hk1xNFCjYQDn8UfCV602p1yHlhVs612UiZC+WFE8VHQJ6wCWWgZMg2ohztWG6msDanzkcvPkTw+yJGpROFA8fVZzSG1lNAYNmBIJdaKQHsiiArO8GF1Z48Emf3msrPlL6j8WKTLZV3Gyxh6FU3vWng450WtmI0fGlTaj6u5no55GO9MJbNlcZjntZQ8/jAfebMme/0e73VTz7yCE+5wwfHsRw82S3fLGnjl5zT6+Z5oY25lex5szzI3o+TedLH3Lh46S2X32F7o5HUDnlnZ4c6r/7s1X+eeOjEp5//yvPEk5MXHZ/Ap3zG43OzX2qPdo9A3ZpE7w9rL8I7GrRkCAJWBguBlzQWY319XU4m+E+8snxCBEKE2FILSUIDN9pL/2DnVWBmyGPtue56O0asOjbHFVPQg8Jc+ZBnKqgKXEg+ePIG4szt0Csf4VRcqygC1peFBYMbUpUG08D7MDfYsPs189vdLyGzqYpE2urOsdWmPWDl2Whjwm58PKCO2djSQeMHkDu7TWYTAjQnXNoM6liDklHjGj44amMzNAaqwxAwKc9nje9VsdV1QlWaoeu4xqSoYw3YmOw2RuWiM6DVVRgorlTGxO3XIBeiLbIUzbICnB0KGlKjJadTPFwZrBRojdsvgck1XzPBYrIqASY32ALQGI0rFGfh3GmscpD86NFwFQ3lBB94Mnma1tT1jOF2w2T8PByTap13ud5CRm2LQJPOjWkhLDBOxYMkWnkSOTLWYkELIK/WJ541F3edeI/jZ4rFYoS8qzMgPLOqqq5iLkabPdXuJ2HR7mkC71i+/aYS48YUS0hV26G3VKYu9CFsPpTrUlplxliCpl/SYaXC70DK8PXZqiFrq7u5yMJSnwayuWs4zbsEakKP7y7xO1+xuQmEd28giaSAJfiCx3sbUKr2Ftbm/HVeO1ITZSsO0ek9hQSShLn8IzF/hpRuvASb0DBUtEEqI6Rch0EpgdGcgIaEagx9eKZy8CrFU9KCMJXmY9hJQF8obU1qXINkUMEmDLa4+4kYOobMtIuVCoDQrKWlOpgRoA2wMpDrDk1Hy0gGPibufj5QZWtrraE0JEx5syjZElodATPd6jTPlF5AnUD7RDKWVQHjatjz1kDT4SzOVSsi4RAuwEpFGT/faxuNRtxY5oZ+JLbY77HPNubii489q2d26UtNY8AxchgnjhnHDTFao/KDPEz5gj99l45f3XS7Pemrqprid0s9bb3Q44uZZusHf5Rh66U+yL73ds1j5WTT8bmuOr4b+7qBi1/sqV4fk7B8cdX03QXoopYBr1KVmZKEXmB8YkeTQWNTWNkgp+U8zmkt+OLFgwm8UsleGrqGnVCWSdRCVEbzIzScLQi8ck08qTaHYKExNIP2pSBrg4xm49RWwzK8O1mzCAXvfg0Hv7wmDAmN8S5nA9bbxqoLCVB9fmaBC2/nAzg31CcKw00niiweamYygAejo1lWHqV+a/OY59FoN9cIf0wyDEcujDB70JLXTqQ9WtEoNoUEDz41o8CkNMckhhurkXYB6FA5PkwuA1dXrTizgVmpnNIW4uFZ0KylTW6HZliMXUZaqblJCoTFBv7wJcr6ulAoYdUbGc3N4J8pwLAXKeUj3lgOdckBzfEXG80/UzENPuuERvMOgZoy80LIY1Dy7Dz1SKXJa5+t1Ie77ho1u6AmdBLaGmhJ6PgsyPjaQ5SVcqwAPz2jpcjYR1h+5koo2VvjoCQnlNpgY6CEuPrrvGylNJg/lSEwSoqMPaOOau8VOTf3CyxBoINlbJegLkhWij9MifG063+H/4GBHBr+gdKAbKopoZyvtvJC1V+RWXIXf5jnLJCjbkRHMcjN83QxqNE5a4elFIQE3GV+S89IzRAgWsvO/w/aVpNrkpXS6sCbX6cyDBNiW+CshDaVFpmKbSZ182jLyyRZKW6JXweyxFPGTiJTNw220DJXiIoN/2APUvGfxpR6xAVBmsrix7/kEo2tNWCrJmP81pp/huIpyl+YTPGXJuGvXrThf7rSZu2hyR+TZC3ax4ZnZfULR/nGFnUdL3zBwk25sVc7/vJF/yJHdj+exC6+f9arg3/4m1WZcWxiryr58j30tsHW0iSuKWMf8vY8F8vRrjXIn5FqDvVJ68iXLmwUWV++t4UYly60EFAPFgbRxPlAvp/fJL+0PEbzcotj1jXEujKe1hYQ+s4rP3rlh08+/eTLz515TlYIt2F2l7quhBmumWh73hMSwTOdxoqeJzDJze0t6pw9e3b11KlTv/zq8y+c4urw0vUZ0lWYDbBsoI2C3fpVzmOKUCKArQ2dfBrg6ak6e9Pp5L83bt78/f8AnxKpaSXLS9kAAAAASUVORK5CYII=';
}
